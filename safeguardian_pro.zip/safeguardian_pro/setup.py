"""
SafeGuardian Pro - Automated Setup Script
=========================================
Handles installation, configuration, and system initialization
"""

import os
import sys
import subprocess
import secrets
from pathlib import Path
def load_excel_data():
    try:
        df = pd.read_excel("training_data.xlsx")
        return df.to_dict('records')
    except:
        return []
def check_python_version():
    """Check if Python version is compatible"""
    version = sys.version_info
    if version.major < 3 or (version.major == 3 and version.minor < 8):
        print("❌ Python 3.8+ required. Current version:", sys.version)
        return False
    print(f"✅ Python {version.major}.{version.minor}.{version.micro} - Compatible")
    return True

def install_packages():
    """Install required packages with fallbacks"""
    packages = [
        'Flask==2.3.3',
        'Flask-CORS==4.0.0', 
        'requests==2.31.0',
        'python-dotenv==1.0.0'
    ]
    
    optional_packages = [
        'Flask-SQLAlchemy==3.0.5',
        'openai==0.27.10',
        'pandas==2.0.3'
    ]
    
    print("📥 Installing essential packages...")
    
    # Try essential packages
    for package in packages:
        try:
            print(f"   Installing {package}...")
            result = subprocess.run([
                sys.executable, '-m', 'pip', 'install', package
            ], capture_output=True, text=True, timeout=60)
            
            if result.returncode == 0:
                print(f"   ✅ {package} installed successfully")
            else:
                print(f"   ❌ {package} failed: {result.stderr}")
                return False
        except Exception as e:
            print(f"   ❌ {package} error: {e}")
            return False
    
    print("\n📦 Installing optional packages...")
    
    # Try optional packages (don't fail if these don't work)
    for package in optional_packages:
        try:
            print(f"   Installing {package}...")
            result = subprocess.run([
                sys.executable, '-m', 'pip', 'install', package
            ], capture_output=True, text=True, timeout=60)
            
            if result.returncode == 0:
                print(f"   ✅ {package} installed successfully")
            else:
                print(f"   ⚠️ {package} skipped (optional): {result.stderr}")
        except Exception as e:
            print(f"   ⚠️ {package} skipped: {e}")
    
    return True

def create_env_file():
    """Create .env configuration file"""
    env_content = f"""# SafeGuardian Pro Configuration
# ==============================

# Flask Secret Key (REQUIRED)
SECRET_KEY={secrets.token_hex(32)}

# Child Safety Video URL (CONFIGURED)
CHILD_SAFETY_VIDEO_URL=https://childsafetyineurope.com/wp-content/uploads/2022/06/ChildSafety_WebsiteLoopx2_V4.mp4

# OpenAI API Key (OPTIONAL - add for real AI responses)
# Get from: https://platform.openai.com/api-keys
# OPENAI_API_KEY=sk-your_openai_api_key_here

# Database URL (OPTIONAL - SQLite by default)
DATABASE_URL=sqlite:///safeguardian_complete.db
"""
    
    if not os.path.exists('.env'):
        with open('.env', 'w') as f:
            f.write(env_content)
        print("✅ Created .env configuration file")
        return True
    else:
        print("⚠️ .env file already exists - keeping existing configuration")
        return True

def create_directories():
    """Create necessary directories"""
    directories = ['logs', 'data', 'uploads', 'backups']
    
    for directory in directories:
        try:
            Path(directory).mkdir(exist_ok=True)
            print(f"✅ Created directory: {directory}")
        except Exception as e:
            print(f"⚠️ Could not create {directory}: {e}")

def test_installation():
    """Test if installation works"""
    print("\n🧪 Testing installation...")
    
    try:
        # Test Flask import
        import flask
        print("✅ Flask import successful")
        
        # Test other imports
        try:
            from flask_cors import CORS
            print("✅ Flask-CORS import successful")
        except ImportError:
            print("⚠️ Flask-CORS not available")
        
        try:
            import requests
            print("✅ Requests import successful")
        except ImportError:
            print("⚠️ Requests not available")
        
        try:
            from dotenv import load_dotenv
            print("✅ Python-dotenv import successful")
        except ImportError:
            print("⚠️ Python-dotenv not available")
        
        # Test optional imports
        try:
            import openai
            print("✅ OpenAI import successful")
        except ImportError:
            print("ℹ️ OpenAI not installed (optional)")
        
        try:
            import pandas
            print("✅ Pandas import successful")
        except ImportError:
            print("ℹ️ Pandas not installed (optional)")
        
        return True
        
    except ImportError as e:
        print(f"❌ Critical import failed: {e}")
        return False

def run_setup():
    """Main setup process"""
    print("🛡️ SafeGuardian Pro - Automated Setup")
    print("=" * 50)
    
    # Check Python version
    if not check_python_version():
        return False
    
    # Install packages
    print("\n📦 Package Installation")
    if not install_packages():
        print("❌ Package installation failed")
        print("\n🆘 Manual installation commands:")
        print("   python -m pip install Flask Flask-CORS requests python-dotenv")
        return False
    
    # Create configuration
    print("\n⚙️ Configuration Setup")
    create_env_file()
    create_directories()
    
    # Test installation
    if test_installation():
        print("\n✅ Setup completed successfully!")
        print("\n🚀 Next Steps:")
        print("1. Run: python main.py")
        print("2. Open: http://localhost:3000")
        print("3. Login with any username/password")
        print("4. Explore all AI prompt engineering techniques!")
        print("\n🔑 Optional: Add OpenAI API key to .env for real AI responses")
        return True
    else:
        print("\n❌ Setup completed with warnings")
        print("Some features may not work - check error messages above")
        return False

if __name__ == '__main__':
    success = run_setup()
    
    if success:
        print("\n🎉 SafeGuardian Pro is ready!")
        print("   All AI prompt engineering techniques available")
        print("   Child safety features active")
        print("   Security protection enabled")
        
        # Ask if user wants to run immediately
        try:
            run_now = input("\n🚀 Run SafeGuardian Pro now? (y/n): ").lower().strip()
            if run_now in ['y', 'yes']:
                print("\n🌟 Starting SafeGuardian Pro...")
                os.system('python main.py')
        except KeyboardInterrupt:
            print("\n👋 Setup complete - run 'python main.py' when ready!")
    else:
        print("\n🔧 Setup had issues - check error messages above")
        print("Try manual installation: pip install Flask Flask-CORS requests python-dotenv")