#!/usr/bin/env python3
"""
Comprehensive OAuth Debug - Find the exact issue
================================================
"""

import os
import requests
from dotenv import load_dotenv

def comprehensive_oauth_debug():
    """Debug OAuth issues comprehensively"""
    print("🛡️ SafeGuardian Pro - Comprehensive OAuth Debug")
    print("=" * 60)
    
    load_dotenv()
    
    # Get credentials
    client_id = os.getenv('GOOGLE_CLIENT_ID', '')
    client_secret = os.getenv('GOOGLE_CLIENT_SECRET', '')
    
    print("📋 STEP 1: Credential Format Check")
    print("=" * 40)
    print(f"Client ID: {client_id}")
    print(f"Client Secret: {client_secret[:10]}..." if client_secret else "NOT SET")
    print()
    
    # Check format
    issues = []
    
    if not client_id:
        issues.append("❌ Client ID is empty")
    elif not client_id.endswith('.apps.googleusercontent.com'):
        issues.append("❌ Client ID doesn't end with .apps.googleusercontent.com")
    elif len(client_id.split('-')[0]) != 12:
        issues.append("❌ Client ID first part should be 12 digits")
    else:
        print("✅ Client ID format looks correct")
    
    if not client_secret:
        issues.append("❌ Client Secret is empty")
    elif not client_secret.startswith('GOCSPX-'):
        issues.append("❌ Client Secret should start with GOCSPX-")
    elif len(client_secret) < 30:
        issues.append("❌ Client Secret seems too short")
    else:
        print("✅ Client Secret format looks correct")
    
    print("📋 STEP 2: Google OAuth Discovery Test")
    print("=" * 40)
    
    # Test Google's OAuth discovery endpoint
    try:
        discovery_url = "https://accounts.google.com/.well-known/openid_configuration"
        response = requests.get(discovery_url, timeout=10)
        if response.status_code == 200:
            print("✅ Google OAuth discovery endpoint accessible")
            discovery_data = response.json()
            print(f"✅ Authorization endpoint: {discovery_data.get('authorization_endpoint', 'Found')}")
        else:
            print(f"❌ Google OAuth discovery failed: {response.status_code}")
    except Exception as e:
        print(f"❌ Network error accessing Google: {e}")
    
    print("\n📋 STEP 3: Client ID Validation Test")
    print("=" * 40)
    
    # Try to validate the client ID by making a request to Google
    if client_id:
        try:
            # This will fail but should give us a specific error about the client
            test_url = f"https://oauth2.googleapis.com/token"
            test_data = {
                'client_id': client_id,
                'client_secret': client_secret,
                'grant_type': 'authorization_code',
                'code': 'test_code',  # This will fail, but we'll get a specific error
                'redirect_uri': 'http://localhost:3000/auth/google/callback'
            }
            
            response = requests.post(test_url, data=test_data, timeout=10)
            error_data = response.json()
            
            if 'error' in error_data:
                error_type = error_data['error']
                if error_type == 'invalid_client':
                    print("❌ CONFIRMED: Google says 'invalid_client'")
                    print("   This means Client ID or Client Secret is wrong")
                elif error_type == 'invalid_grant':
                    print("✅ Client ID and Secret are VALID!")
                    print("   (The 'invalid_grant' error is expected with test code)")
                else:
                    print(f"⚠️ Unexpected error: {error_type}")
                    print(f"   Description: {error_data.get('error_description', 'N/A')}")
            
        except Exception as e:
            print(f"🔍 Client validation test error: {e}")
    
    print("\n📋 STEP 4: Recommendations")
    print("=" * 40)
    
    if issues:
        print("❌ Issues Found:")
        for issue in issues:
            print(f"   {issue}")
        print()
    
    print("🔧 Next Steps to Fix 'invalid_client' Error:")
    print("1. 🌐 Go to Google Cloud Console")
    print("2. 🔍 Navigate to APIs & Services > Credentials")
    print("3. 📋 Find your OAuth 2.0 Client ID")
    print("4. ✏️ Click to edit and verify the Client ID matches exactly")
    print("5. 🔑 Generate a NEW Client Secret (the current one might be wrong)")
    print("6. 📝 Copy the NEW credentials to your .env file")
    print("7. ⚡ Restart your application")
    
    print("\n🆘 If Still Not Working:")
    print("1. 🗑️ Delete the current OAuth client completely")
    print("2. ➕ Create a brand new OAuth 2.0 Client ID")
    print("3. 🔧 Configure with these settings:")
    print("   - Application type: Web application")
    print("   - Authorized JavaScript origins: http://localhost:3000")
    print("   - Authorized redirect URIs: http://localhost:3000/auth/google/callback")
    print("4. 📝 Use the NEW Client ID and Secret")
    
    return len(issues) == 0

if __name__ == '__main__':
    comprehensive_oauth_debug()