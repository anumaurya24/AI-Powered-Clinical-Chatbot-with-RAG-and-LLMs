"""
Database Models - Complete Schema (Fixed)
=========================================
Advanced database models for SafeGuardian Pro with comprehensive tracking
Fixed: Removed reserved attribute names like 'metadata'
"""

from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timedelta
import json
from typing import Dict, Any, Optional

db = SQLAlchemy()

class User(db.Model):
    """Enhanced User model with comprehensive tracking"""
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    google_id = db.Column(db.String(100), unique=True, nullable=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    name = db.Column(db.String(100), nullable=False)
    age = db.Column(db.Integer, default=16)
    profile_picture = db.Column(db.String(200))
    
    # Enhanced user data
    grade_level = db.Column(db.String(20), default='high_school')
    school_district = db.Column(db.String(100))
    parent_email = db.Column(db.String(120))
    emergency_contact = db.Column(db.String(120))
    
    # Privacy and security settings
    privacy_level = db.Column(db.String(20), default='standard')  # standard, high, maximum
    notifications_enabled = db.Column(db.Boolean, default=True)
    crisis_alerts_enabled = db.Column(db.Boolean, default=True)
    parent_notifications = db.Column(db.Boolean, default=True)
    
    # Activity tracking
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    last_active = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    last_login = db.Column(db.DateTime, default=datetime.utcnow)
    total_conversations = db.Column(db.Integer, default=0)
    total_crisis_interventions = db.Column(db.Integer, default=0)
    
    # Risk assessment
    current_risk_level = db.Column(db.String(20), default='low')  # low, medium, high, critical
    risk_factors = db.Column(db.Text)  # JSON string of risk factors
    last_risk_assessment = db.Column(db.DateTime)
    
    # Relationships
    conversations = db.relationship('Conversation', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    crisis_incidents = db.relationship('CrisisIncident', backref='user', lazy='dynamic')
    user_feedback = db.relationship('UserFeedback', backref='user', lazy='dynamic')
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert user to dictionary"""
        return {
            'id': self.id,
            'email': self.email,
            'name': self.name,
            'age': self.age,
            'profile_picture': self.profile_picture,
            'grade_level': self.grade_level,
            'privacy_level': self.privacy_level,
            'current_risk_level': self.current_risk_level,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_active': self.last_active.isoformat() if self.last_active else None,
            'total_conversations': self.total_conversations,
            'notifications_enabled': self.notifications_enabled
        }
    
    def update_risk_level(self, new_level: str, risk_factors: Dict[str, Any]):
        """Update user's risk assessment"""
        self.current_risk_level = new_level
        self.risk_factors = json.dumps(risk_factors)
        self.last_risk_assessment = datetime.utcnow()
    
    def get_risk_factors(self) -> Dict[str, Any]:
        """Get parsed risk factors"""
        if self.risk_factors:
            try:
                return json.loads(self.risk_factors)
            except:
                return {}
        return {}
    
    def __repr__(self):
        return f'<User {self.email}>'

class Conversation(db.Model):
    """Enhanced Conversation model with comprehensive analysis tracking"""
    __tablename__ = 'conversations'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    
    # Core conversation data
    message = db.Column(db.Text, nullable=False)
    response = db.Column(db.Text, nullable=False)
    conversation_type = db.Column(db.String(50), default='general')  # general, crisis, cyberbullying, safety
    
    # Analysis results
    risk_level = db.Column(db.String(50), index=True)
    confidence_score = db.Column(db.Float)
    is_cyberbullying = db.Column(db.Boolean, default=False)
    threat_detected = db.Column(db.Boolean, default=False)
    
    # AI and analysis data (RENAMED from 'metadata')
    analysis_method = db.Column(db.String(100))  # zero_shot, few_shot, etc.
    openai_used = db.Column(db.Boolean, default=False)
    model_used = db.Column(db.String(50))  # gpt-3.5-turbo, gpt-4, etc.
    tokens_used = db.Column(db.Integer)
    response_time = db.Column(db.Float)
    
    # Detailed analysis results (JSON) - RENAMED
    analysis_details = db.Column(db.Text)  # Full analysis results as JSON
    rag_context_used = db.Column(db.Text)  # RAG contexts used as JSON
    security_flags = db.Column(db.Text)    # Security analysis as JSON
    
    # Follow-up and intervention tracking
    intervention_triggered = db.Column(db.Boolean, default=False)
    adult_notified = db.Column(db.Boolean, default=False)
    crisis_escalated = db.Column(db.Boolean, default=False)
    follow_up_needed = db.Column(db.Boolean, default=False)
    follow_up_completed = db.Column(db.Boolean, default=False)
    
    # Platform and context
    platform_source = db.Column(db.String(50))  # Where the original issue occurred
    device_type = db.Column(db.String(50))      # mobile, desktop, tablet
    location = db.Column(db.String(100))        # General location for context
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def set_analysis_details(self, analysis_data: Dict[str, Any]):
        """Store detailed analysis results"""
        self.analysis_details = json.dumps(analysis_data)
    
    def get_analysis_details(self) -> Dict[str, Any]:
        """Get parsed analysis details"""
        if self.analysis_details:
            try:
                return json.loads(self.analysis_details)
            except:
                return {}
        return {}
    
    def set_rag_context(self, rag_data: Dict[str, Any]):
        """Store RAG context used"""
        self.rag_context_used = json.dumps(rag_data)
    
    def get_rag_context(self) -> Dict[str, Any]:
        """Get parsed RAG context"""
        if self.rag_context_used:
            try:
                return json.loads(self.rag_context_used)
            except:
                return {}
        return {}
    
    def set_security_flags(self, security_data: Dict[str, Any]):
        """Store security analysis results"""
        self.security_flags = json.dumps(security_data)
    
    def get_security_flags(self) -> Dict[str, Any]:
        """Get parsed security flags"""
        if self.security_flags:
            try:
                return json.loads(self.security_flags)
            except:
                return {}
        return {}
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert conversation to dictionary"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'message': self.message,
            'response': self.response,
            'conversation_type': self.conversation_type,
            'risk_level': self.risk_level,
            'confidence_score': self.confidence_score,
            'is_cyberbullying': self.is_cyberbullying,
            'threat_detected': self.threat_detected,
            'analysis_method': self.analysis_method,
            'openai_used': self.openai_used,
            'model_used': self.model_used,
            'tokens_used': self.tokens_used,
            'response_time': self.response_time,
            'intervention_triggered': self.intervention_triggered,
            'adult_notified': self.adult_notified,
            'crisis_escalated': self.crisis_escalated,
            'platform_source': self.platform_source,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'analysis_details': self.get_analysis_details(),
            'rag_context': self.get_rag_context(),
            'security_flags': self.get_security_flags()
        }
    
    def __repr__(self):
        return f'<Conversation {self.id}: {self.risk_level}>'

class CrisisIncident(db.Model):
    """Crisis incident tracking and intervention management"""
    __tablename__ = 'crisis_incidents'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    conversation_id = db.Column(db.Integer, db.ForeignKey('conversations.id'))
    
    # Crisis details
    crisis_type = db.Column(db.String(50), nullable=False)  # suicide_ideation, self_harm, severe_bullying
    severity_level = db.Column(db.String(20), nullable=False)  # critical, high, moderate
    crisis_indicators = db.Column(db.Text)  # JSON of detected indicators
    
    # Intervention tracking
    intervention_status = db.Column(db.String(50), default='initiated')  # initiated, in_progress, resolved, escalated
    emergency_services_contacted = db.Column(db.Boolean, default=False)
    crisis_line_contacted = db.Column(db.Boolean, default=False)
    adults_notified = db.Column(db.Boolean, default=False)
    professional_referral = db.Column(db.Boolean, default=False)
    
    # Response details
    immediate_actions_taken = db.Column(db.Text)  # JSON list of actions
    resources_provided = db.Column(db.Text)      # JSON list of resources
    follow_up_plan = db.Column(db.Text)          # JSON follow-up plan
    
    # Personnel involved
    crisis_counselor_assigned = db.Column(db.String(100))
    school_personnel_notified = db.Column(db.String(200))
    parent_guardian_contacted = db.Column(db.Boolean, default=False)
    
    # Outcome tracking
    resolution_status = db.Column(db.String(50))  # resolved, ongoing, escalated, transferred
    outcome_notes = db.Column(db.Text)
    safety_plan_created = db.Column(db.Boolean, default=False)
    
    # Timestamps
    incident_detected = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    first_response = db.Column(db.DateTime)
    resolution_time = db.Column(db.DateTime)
    last_follow_up = db.Column(db.DateTime)
    
    def set_crisis_indicators(self, indicators: Dict[str, Any]):
        """Store crisis indicators"""
        self.crisis_indicators = json.dumps(indicators)
    
    def get_crisis_indicators(self) -> Dict[str, Any]:
        """Get parsed crisis indicators"""
        if self.crisis_indicators:
            try:
                return json.loads(self.crisis_indicators)
            except:
                return {}
        return {}
    
    def add_action_taken(self, action: str):
        """Add action to the list of actions taken"""
        actions = self.get_actions_taken()
        actions.append({
            'action': action,
            'timestamp': datetime.utcnow().isoformat()
        })
        self.immediate_actions_taken = json.dumps(actions)
    
    def get_actions_taken(self) -> list:
        """Get list of actions taken"""
        if self.immediate_actions_taken:
            try:
                return json.loads(self.immediate_actions_taken)
            except:
                return []
        return []
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert crisis incident to dictionary"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'conversation_id': self.conversation_id,
            'crisis_type': self.crisis_type,
            'severity_level': self.severity_level,
            'intervention_status': self.intervention_status,
            'emergency_services_contacted': self.emergency_services_contacted,
            'crisis_line_contacted': self.crisis_line_contacted,
            'adults_notified': self.adults_notified,
            'resolution_status': self.resolution_status,
            'incident_detected': self.incident_detected.isoformat() if self.incident_detected else None,
            'crisis_indicators': self.get_crisis_indicators(),
            'actions_taken': self.get_actions_taken()
        }
    
    def __repr__(self):
        return f'<CrisisIncident {self.id}: {self.crisis_type} - {self.severity_level}>'

class FineTuningData(db.Model):
    """Fine-tuning data collection for continuous AI improvement"""
    __tablename__ = 'fine_tuning_data'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # Training data
    prompt = db.Column(db.Text, nullable=False)
    completion = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(100), index=True)
    
    # Quality metrics
    quality_score = db.Column(db.Float)  # 0.0 to 1.0
    user_feedback_rating = db.Column(db.Integer)  # 1-5 rating
    expert_validation = db.Column(db.Boolean)
    
    # Data source info (RENAMED from 'metadata')
    source_conversation_id = db.Column(db.Integer, db.ForeignKey('conversations.id'))
    data_type = db.Column(db.String(50))  # user_feedback, expert_review, synthetic
    validation_status = db.Column(db.String(50), default='pending')  # pending, approved, rejected
    
    # Training info (RENAMED)
    used_in_training = db.Column(db.Boolean, default=False)
    training_batch_id = db.Column(db.String(100))
    model_version = db.Column(db.String(50))
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    validated_at = db.Column(db.DateTime)
    trained_at = db.Column(db.DateTime)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert fine-tuning data to dictionary"""
        return {
            'id': self.id,
            'prompt': self.prompt,
            'completion': self.completion,
            'category': self.category,
            'quality_score': self.quality_score,
            'user_feedback_rating': self.user_feedback_rating,
            'validation_status': self.validation_status,
            'used_in_training': self.used_in_training,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
    
    def __repr__(self):
        return f'<FineTuningData {self.id}: {self.category}>'

class UserFeedback(db.Model):
    """User feedback and satisfaction tracking"""
    __tablename__ = 'user_feedback'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    conversation_id = db.Column(db.Integer, db.ForeignKey('conversations.id'))
    
    # Feedback details
    feedback_type = db.Column(db.String(50))  # response_quality, feature_request, bug_report, general
    rating = db.Column(db.Integer)  # 1-5 star rating
    feedback_text = db.Column(db.Text)
    
    # Specific ratings
    helpfulness_rating = db.Column(db.Integer)  # 1-5
    accuracy_rating = db.Column(db.Integer)     # 1-5
    safety_rating = db.Column(db.Integer)       # 1-5
    age_appropriateness = db.Column(db.Integer) # 1-5
    
    # Improvement suggestions
    suggested_improvements = db.Column(db.Text)
    would_recommend = db.Column(db.Boolean)
    
    # Response tracking
    staff_response = db.Column(db.Text)
    response_status = db.Column(db.String(50), default='pending')  # pending, acknowledged, resolved
    
    # Timestamps
    submitted_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    responded_at = db.Column(db.DateTime)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert feedback to dictionary"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'conversation_id': self.conversation_id,
            'feedback_type': self.feedback_type,
            'rating': self.rating,
            'feedback_text': self.feedback_text,
            'helpfulness_rating': self.helpfulness_rating,
            'accuracy_rating': self.accuracy_rating,
            'safety_rating': self.safety_rating,
            'would_recommend': self.would_recommend,
            'response_status': self.response_status,
            'submitted_at': self.submitted_at.isoformat() if self.submitted_at else None
        }
    
    def __repr__(self):
        return f'<UserFeedback {self.id}: {self.rating}/5>'

class SecurityIncident(db.Model):
    """Security incident tracking for threat monitoring"""
    __tablename__ = 'security_incidents'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), index=True)
    
    # Incident details
    incident_type = db.Column(db.String(50), nullable=False)  # prompt_injection, jailbreak, etc.
    severity_level = db.Column(db.String(20), nullable=False)
    threat_content = db.Column(db.Text, nullable=False)
    
    # Detection details
    detection_method = db.Column(db.String(100))
    confidence_score = db.Column(db.Float)
    threat_patterns_matched = db.Column(db.Text)  # JSON of matched patterns
    
    # Response
    blocked = db.Column(db.Boolean, default=True)
    response_action = db.Column(db.String(100))
    escalated = db.Column(db.Boolean, default=False)
    
    # Analysis info (RENAMED)
    ip_address = db.Column(db.String(45))  # IPv4 or IPv6
    user_agent = db.Column(db.String(500))
    session_info = db.Column(db.Text)  # JSON session data
    
    # Timestamps
    detected_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    resolved_at = db.Column(db.DateTime)
    
    def set_threat_patterns(self, patterns: list):
        """Store matched threat patterns"""
        self.threat_patterns_matched = json.dumps(patterns)
    
    def get_threat_patterns(self) -> list:
        """Get parsed threat patterns"""
        if self.threat_patterns_matched:
            try:
                return json.loads(self.threat_patterns_matched)
            except:
                return []
        return []
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert security incident to dictionary"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'incident_type': self.incident_type,
            'severity_level': self.severity_level,
            'detection_method': self.detection_method,
            'confidence_score': self.confidence_score,
            'blocked': self.blocked,
            'escalated': self.escalated,
            'detected_at': self.detected_at.isoformat() if self.detected_at else None,
            'threat_patterns': self.get_threat_patterns()
        }
    
    def __repr__(self):
        return f'<SecurityIncident {self.id}: {self.incident_type}>'

class SystemMetrics(db.Model):
    """System performance and usage metrics"""
    __tablename__ = 'system_metrics'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # Metric details
    metric_type = db.Column(db.String(50), nullable=False, index=True)  # usage, performance, security
    metric_name = db.Column(db.String(100), nullable=False)
    metric_value = db.Column(db.Float, nullable=False)
    metric_unit = db.Column(db.String(20))  # requests, seconds, percentage, count
    
    # Context
    time_period = db.Column(db.String(20))  # hourly, daily, weekly, monthly
    component = db.Column(db.String(50))    # rag, security, ai, dataset
    
    # Additional data (RENAMED from 'metadata')
    additional_data = db.Column(db.Text)  # JSON for additional metric data
    
    # Timestamps
    recorded_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    period_start = db.Column(db.DateTime)
    period_end = db.Column(db.DateTime)
    
    def set_additional_data(self, data: Dict[str, Any]):
        """Store metric additional data"""
        self.additional_data = json.dumps(data)
    
    def get_additional_data(self) -> Dict[str, Any]:
        """Get parsed additional data"""
        if self.additional_data:
            try:
                return json.loads(self.additional_data)
            except:
                return {}
        return {}
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert metric to dictionary"""
        return {
            'id': self.id,
            'metric_type': self.metric_type,
            'metric_name': self.metric_name,
            'metric_value': self.metric_value,
            'metric_unit': self.metric_unit,
            'time_period': self.time_period,
            'component': self.component,
            'recorded_at': self.recorded_at.isoformat() if self.recorded_at else None,
            'additional_data': self.get_additional_data()
        }
    
    @classmethod
    def record_metric(cls, metric_type: str, metric_name: str, value: float, 
                     unit: str = 'count', component: str = 'system', 
                     time_period: str = 'instant', additional_data: Dict[str, Any] = None):
        """Helper method to record a metric"""
        metric = cls(
            metric_type=metric_type,
            metric_name=metric_name,
            metric_value=value,
            metric_unit=unit,
            component=component,
            time_period=time_period
        )
        
        if additional_data:
            metric.set_additional_data(additional_data)
        
        db.session.add(metric)
        return metric
    
    def __repr__(self):
        return f'<SystemMetric {self.metric_name}: {self.metric_value} {self.metric_unit}>'

class KnowledgeBase(db.Model):
    """Dynamic knowledge base for RAG system"""
    __tablename__ = 'knowledge_base'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # Content
    category = db.Column(db.String(100), nullable=False, index=True)
    content = db.Column(db.Text, nullable=False)
    title = db.Column(db.String(200))
    source = db.Column(db.String(200))  # Where this knowledge came from
    
    # Classification
    content_type = db.Column(db.String(50))  # guidance, resource, protocol, faq
    age_appropriate_min = db.Column(db.Integer, default=10)
    age_appropriate_max = db.Column(db.Integer, default=18)
    
    # Quality and validation
    quality_score = db.Column(db.Float, default=0.5)
    expert_validated = db.Column(db.Boolean, default=False)
    usage_count = db.Column(db.Integer, default=0)
    effectiveness_rating = db.Column(db.Float)  # Based on user feedback
    
    # Additional info (RENAMED from 'metadata')
    tags = db.Column(db.Text)  # JSON list of tags
    related_categories = db.Column(db.Text)  # JSON list of related categories
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_used = db.Column(db.DateTime)
    
    def set_tags(self, tags: list):
        """Store tags as JSON"""
        self.tags = json.dumps(tags)
    
    def get_tags(self) -> list:
        """Get parsed tags"""
        if self.tags:
            try:
                return json.loads(self.tags)
            except:
                return []
        return []
    
    def increment_usage(self):
        """Increment usage counter and update last used"""
        self.usage_count += 1
        self.last_used = datetime.utcnow()
    
    def is_age_appropriate(self, user_age: int) -> bool:
        """Check if content is appropriate for user age"""
        return self.age_appropriate_min <= user_age <= self.age_appropriate_max
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert knowledge base entry to dictionary"""
        return {
            'id': self.id,
            'category': self.category,
            'content': self.content,
            'title': self.title,
            'source': self.source,
            'content_type': self.content_type,
            'age_range': f"{self.age_appropriate_min}-{self.age_appropriate_max}",
            'quality_score': self.quality_score,
            'expert_validated': self.expert_validated,
            'usage_count': self.usage_count,
            'tags': self.get_tags(),
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_used': self.last_used.isoformat() if self.last_used else None
        }
    
    def __repr__(self):
        return f'<KnowledgeBase {self.category}: {self.title}>'

class AuditLog(db.Model):
    """Comprehensive audit logging for system activities"""
    __tablename__ = 'audit_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # Who and what
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), index=True)
    action_type = db.Column(db.String(50), nullable=False, index=True)
    action_description = db.Column(db.String(200), nullable=False)
    
    # Context
    resource_type = db.Column(db.String(50))  # conversation, user, system, etc.
    resource_id = db.Column(db.Integer)
    session_id = db.Column(db.String(100))
    
    # Request details
    ip_address = db.Column(db.String(45))
    user_agent = db.Column(db.String(500))
    request_method = db.Column(db.String(10))
    request_path = db.Column(db.String(200))
    
    # Results
    success = db.Column(db.Boolean, default=True)
    error_message = db.Column(db.Text)
    response_time = db.Column(db.Float)
    
    # Additional data (RENAMED from 'additional_data')
    extra_data = db.Column(db.Text)  # JSON for extra context
    
    # Timestamp
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    
    def set_extra_data(self, data: Dict[str, Any]):
        """Store extra audit data"""
        self.extra_data = json.dumps(data)
    
    def get_extra_data(self) -> Dict[str, Any]:
        """Get parsed extra data"""
        if self.extra_data:
            try:
                return json.loads(self.extra_data)
            except:
                return {}
        return {}
    
    @classmethod
    def log_action(cls, user_id: Optional[int], action_type: str, description: str,
                   resource_type: str = None, resource_id: int = None,
                   success: bool = True, error_message: str = None,
                   extra_data: Dict[str, Any] = None):
        """Helper method to log an action"""
        log_entry = cls(
            user_id=user_id,
            action_type=action_type,
            action_description=description,
            resource_type=resource_type,
            resource_id=resource_id,
            success=success,
            error_message=error_message
        )
        
        if extra_data:
            log_entry.set_extra_data(extra_data)
        
        db.session.add(log_entry)
        return log_entry
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert audit log to dictionary"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'action_type': self.action_type,
            'action_description': self.action_description,
            'resource_type': self.resource_type,
            'resource_id': self.resource_id,
            'success': self.success,
            'error_message': self.error_message,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'extra_data': self.get_extra_data()
        }
    
    def __repr__(self):
        return f'<AuditLog {self.id}: {self.action_type}>'

# Database utility functions
def create_all_tables(app):
    """Create all database tables"""
    with app.app_context():
        db.create_all()
        print("✅ All database tables created successfully")

def get_system_statistics() -> Dict[str, Any]:
    """Get comprehensive system statistics"""
    stats = {}
    
    try:
        # User statistics
        stats['users'] = {
            'total_users': User.query.count(),
            'active_users_24h': User.query.filter(
                User.last_active >= datetime.utcnow() - timedelta(hours=24)
            ).count(),
            'high_risk_users': User.query.filter(
                User.current_risk_level.in_(['high', 'critical'])
            ).count()
        }
        
        # Conversation statistics
        stats['conversations'] = {
            'total_conversations': Conversation.query.count(),
            'cyberbullying_detected': Conversation.query.filter(
                Conversation.is_cyberbullying == True
            ).count(),
            'crisis_interventions': Conversation.query.filter(
                Conversation.crisis_escalated == True
            ).count(),
            'avg_confidence_score': db.session.query(
                db.func.avg(Conversation.confidence_score)
            ).scalar() or 0
        }
        
        # Security statistics
        stats['security'] = {
            'total_incidents': SecurityIncident.query.count(),
            'blocked_attacks': SecurityIncident.query.filter(
                SecurityIncident.blocked == True
            ).count(),
            'critical_incidents': SecurityIncident.query.filter(
                SecurityIncident.severity_level == 'critical'
            ).count()
        }
        
        # Performance statistics
        stats['performance'] = {
            'avg_response_time': db.session.query(
                db.func.avg(Conversation.response_time)
            ).scalar() or 0,
            'total_tokens_used': db.session.query(
                db.func.sum(Conversation.tokens_used)
            ).scalar() or 0
        }
        
    except Exception as e:
        print(f"Error calculating statistics: {e}")
        stats['error'] = str(e)
    
    return stats

def cleanup_old_data(days_to_keep: int = 90):
    """Clean up old data to maintain performance"""
    cutoff_date = datetime.utcnow() - timedelta(days=days_to_keep)
    
    try:
        # Clean old audit logs
        old_logs = AuditLog.query.filter(AuditLog.timestamp < cutoff_date).count()
        AuditLog.query.filter(AuditLog.timestamp < cutoff_date).delete()
        
        # Clean old system metrics
        old_metrics = SystemMetrics.query.filter(SystemMetrics.recorded_at < cutoff_date).count()
        SystemMetrics.query.filter(SystemMetrics.recorded_at < cutoff_date).delete()
        
        # Clean resolved security incidents (keep critical ones longer)
        old_security = SecurityIncident.query.filter(
            SecurityIncident.detected_at < cutoff_date,
            SecurityIncident.severity_level != 'critical'
        ).count()
        SecurityIncident.query.filter(
            SecurityIncident.detected_at < cutoff_date,
            SecurityIncident.severity_level != 'critical'
        ).delete()
        
        db.session.commit()
        
        print(f"✅ Cleaned up old data: {old_logs} logs, {old_metrics} metrics, {old_security} security incidents")
        return True
        
    except Exception as e:
        db.session.rollback()
        print(f"❌ Error cleaning up data: {e}")
        return False

# Initialize database helper
def init_database(app):
    """Initialize database with app context"""
    db.init_app(app)
    
    with app.app_context():
        # Create tables
        db.create_all()
        
        # Create initial system metrics
        SystemMetrics.record_metric(
            'system', 'initialization', 1.0, 'event', 'database', 'instant',
            {'initialized_at': datetime.utcnow().isoformat()}
        )
        
        db.session.commit()
        print("✅ Database initialized successfully")

if __name__ == '__main__':
    print("Database Models for SafeGuardian Pro (Fixed Version)")
    print("=================================================")
    print("Models available:")
    print("- User: Enhanced user tracking with risk assessment")
    print("- Conversation: Comprehensive conversation analysis")
    print("- CrisisIncident: Crisis intervention tracking")
    print("- FineTuningData: AI improvement data collection")
    print("- UserFeedback: User satisfaction tracking")
    print("- SecurityIncident: Security threat monitoring")
    print("- SystemMetrics: Performance monitoring")
    print("- KnowledgeBase: Dynamic RAG knowledge")
    print("- AuditLog: Comprehensive audit trail")
    print("✅ All reserved attribute names fixed!")