"""
Dataset Analyzer - Cyberbullying Detection
==========================================
Advanced analysis using your 500-record cyberbullying dataset
"""

import os
import hashlib
import logging
from datetime import datetime
from typing import Dict, List, Any, Optional
import pandas as pd

logger = logging.getLogger(__name__)

class UltimateCyberbullyingAnalyzer:
    """Ultimate analysis using your cyberbullying dataset with ML-style processing"""
    
    def __init__(self):
        self.dataset = []
        self.analysis_cache = {}
        self.pattern_library = {}
        self.stats = {}
        self.toxicity_patterns = {}
        self.platform_patterns = {}
        
        # Load and process dataset
        self.load_dataset()
        self._build_advanced_models()
        self._extract_toxicity_patterns()
        self._analyze_platform_patterns()
        
        logger.info(f"✅ Ultimate Dataset Analyzer: {len(self.dataset)} records loaded and processed")
    
    def load_dataset(self):
        """Load and comprehensively process your cyberbullying dataset"""
        try:
            if os.path.exists('cyberbullying_detection_dataset.csv'):
                df = pd.read_csv('cyberbullying_detection_dataset.csv')
                logger.info(f"📊 Loading your cyberbullying dataset: {len(df)} rows")
                
                processed = 0
                skipped = 0
                
                for _, row in df.iterrows():
                    try:
                        # Extract and validate all fields from your dataset
                        text_content = str(row.get('Text Content', '')).strip()
                        
                        if not text_content or len(text_content) < 3:
                            skipped += 1
                            continue
                        
                        record = {
                            'text_content': text_content,
                            'sentiment_score': self._safe_float(row.get('Sentiment Score', 0)),
                            'reported_flag': str(row.get('Reported Flag', 'No')),
                            'reporting_frequency': self._safe_int(row.get('Reporting Frequency', 0)),
                            'content_type': str(row.get('Content Type', 'Unknown')),
                            'engagement_metrics': str(row.get('Engagement Metrics (Likes, Shares, Comments)', '')),
                            'user_metadata': str(row.get('User Metadata (Age, Gender, Location)', '')),
                            'text_length': len(text_content),
                            'image_content': str(row.get('Image Content', '')),
                            'video_content': str(row.get('Video Content', '')),
                            'interaction_type': str(row.get('Interaction Type (Language)', '')),
                            
                            # Derived features for enhanced analysis
                            'word_count': len(text_content.split()),
                            'contains_caps': text_content.isupper(),
                            'exclamation_count': text_content.count('!'),
                            'question_count': text_content.count('?'),
                            'profanity_indicators': self._detect_profanity_indicators(text_content),
                            'threat_level': self._assess_threat_level(text_content, self._safe_float(row.get('Sentiment Score', 0))),
                            'target_personal': self._detect_personal_attacks(text_content),
                            'processed_timestamp': datetime.now().isoformat()
                        }
                        
                        self.dataset.append(record)
                        processed += 1
                        
                    except Exception as e:
                        skipped += 1
                        logger.warning(f"Error processing row: {e}")
                        continue
                
                logger.info(f"✅ Dataset processed: {processed} valid records, {skipped} skipped")
                self._calculate_comprehensive_stats()
                
            else:
                logger.warning("cyberbullying_detection_dataset.csv not found - creating enhanced sample data")
                self._create_comprehensive_sample_data()
                
        except Exception as e:
            logger.error(f"Dataset loading error: {e}")
            self._create_comprehensive_sample_data()
    
    def _safe_float(self, value, default=0.0):
        """Safely convert value to float"""
        try:
            return float(value) if pd.notna(value) else default
        except:
            return default
    
    def _safe_int(self, value, default=0):
        """Safely convert value to int"""
        try:
            return int(value) if pd.notna(value) else default
        except:
            return default
    
    def _detect_profanity_indicators(self, text: str) -> int:
        """Detect profanity indicators without explicit word lists"""
        indicators = 0
        text_lower = text.lower()
        
        # Pattern-based detection
        patterns = [
            r'\b\w*[#@$%&*]\w*\b',  # Censored words
            r'\b\w*\*{2,}\w*\b',    # Asterisk censoring
            r'\b[a-z]\*+[a-z]\b',   # Single letter with asterisks
        ]
        
        for pattern in patterns:
            import re
            if re.search(pattern, text_lower):
                indicators += 1
        
        return indicators
    
    def _assess_threat_level(self, text: str, sentiment: float) -> str:
        """Assess threat level based on content and sentiment"""
        text_lower = text.lower()
        
        # Critical threat indicators
        critical_words = ['kill', 'die', 'hurt', 'harm', 'destroy', 'hate']
        high_words = ['stupid', 'ugly', 'loser', 'worthless', 'nobody']
        
        critical_count = sum(1 for word in critical_words if word in text_lower)
        high_count = sum(1 for word in high_words if word in text_lower)
        
        if critical_count > 0 and sentiment < -0.8:
            return 'critical'
        elif (critical_count > 0 or high_count > 2) and sentiment < -0.6:
            return 'high'
        elif high_count > 0 and sentiment < -0.4:
            return 'medium'
        else:
            return 'low'
    
    def _detect_personal_attacks(self, text: str) -> bool:
        """Detect if content contains personal attacks"""
        personal_attack_patterns = [
            r'\byou are\b.*\b(stupid|ugly|worthless|loser|dumb)',
            r'\byou\b.*\b(suck|fail|horrible|terrible|awful)',
            r'\bkill yourself\b',
            r'\bnobody likes you\b',
            r'\byou should\b.*\b(die|disappear|leave)'
        ]
        
        import re
        text_lower = text.lower()
        
        for pattern in personal_attack_patterns:
            if re.search(pattern, text_lower):
                return True
        
        return False
    
    def _build_advanced_models(self):
        """Build advanced analysis models from your dataset"""
        if not self.dataset:
            return
        
        # Build comprehensive pattern library
        for record in self.dataset:
            words = record['text_content'].lower().split()
            sentiment = record['sentiment_score']
            reported = record['reported_flag'] == 'Yes'
            
            # Extract harmful word patterns with enhanced features
            if sentiment < -0.3 or reported:  # Include more data for pattern building
                for word in words:
                    if len(word) > 2:  # Include shorter words for better coverage
                        if word not in self.pattern_library:
                            self.pattern_library[word] = {
                                'frequency': 0,
                                'total_sentiment': 0,
                                'avg_sentiment': 0,
                                'report_count': 0,
                                'report_rate': 0,
                                'threat_associations': [],
                                'platforms': set(),
                                'context_patterns': []
                            }
                        
                        pattern_data = self.pattern_library[word]
                        pattern_data['frequency'] += 1
                        pattern_data['total_sentiment'] += sentiment
                        pattern_data['avg_sentiment'] = pattern_data['total_sentiment'] / pattern_data['frequency']
                        pattern_data['platforms'].add(record['content_type'])
                        
                        if reported:
                            pattern_data['report_count'] += 1
                        
                        pattern_data['report_rate'] = (
                            pattern_data['report_count'] / pattern_data['frequency']
                        )
                        
                        # Track threat associations
                        if record['threat_level'] not in pattern_data['threat_associations']:
                            pattern_data['threat_associations'].append(record['threat_level'])
        
        # Convert sets to lists for JSON serialization
        for word_data in self.pattern_library.values():
            word_data['platforms'] = list(word_data['platforms'])
        
        logger.info(f"📚 Built advanced pattern library with {len(self.pattern_library)} word patterns")
    
    def _extract_toxicity_patterns(self):
        """Extract toxicity patterns from dataset"""
        if not self.dataset:
            return
        
        toxicity_levels = ['critical', 'high', 'medium', 'low']
        
        for level in toxicity_levels:
            self.toxicity_patterns[level] = {
                'common_words': [],
                'phrase_patterns': [],
                'sentiment_range': [],
                'typical_length': 0,
                'report_likelihood': 0
            }
        
        # Group by threat level
        level_groups = {}
        for record in self.dataset:
            level = record['threat_level']
            if level not in level_groups:
                level_groups[level] = []
            level_groups[level].append(record)
        
        # Extract patterns for each level
        for level, records in level_groups.items():
            if level in self.toxicity_patterns:
                # Common words
                word_freq = {}
                sentiments = []
                lengths = []
                reported_count = 0
                
                for record in records:
                    words = record['text_content'].lower().split()
                    for word in words:
                        word_freq[word] = word_freq.get(word, 0) + 1
                    
                    sentiments.append(record['sentiment_score'])
                    lengths.append(record['text_length'])
                    
                    if record['reported_flag'] == 'Yes':
                        reported_count += 1
                
                # Extract top words for this toxicity level
                sorted_words = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)
                self.toxicity_patterns[level]['common_words'] = [
                    {'word': word, 'frequency': freq} 
                    for word, freq in sorted_words[:20]
                ]
                
                # Calculate statistics
                if sentiments:
                    self.toxicity_patterns[level]['sentiment_range'] = [
                        min(sentiments), max(sentiments), sum(sentiments) / len(sentiments)
                    ]
                
                if lengths:
                    self.toxicity_patterns[level]['typical_length'] = sum(lengths) / len(lengths)
                
                self.toxicity_patterns[level]['report_likelihood'] = (
                    reported_count / len(records) if records else 0
                )
    
    def _analyze_platform_patterns(self):
        """Analyze patterns specific to different platforms"""
        if not self.dataset:
            return
        
        platform_data = {}
        
        for record in self.dataset:
            platform = record['content_type']
            if platform not in platform_data:
                platform_data[platform] = {
                    'total_posts': 0,
                    'reported_posts': 0,
                    'avg_sentiment': 0,
                    'total_sentiment': 0,
                    'threat_levels': {'critical': 0, 'high': 0, 'medium': 0, 'low': 0},
                    'common_patterns': []
                }
            
            data = platform_data[platform]
            data['total_posts'] += 1
            data['total_sentiment'] += record['sentiment_score']
            data['avg_sentiment'] = data['total_sentiment'] / data['total_posts']
            
            if record['reported_flag'] == 'Yes':
                data['reported_posts'] += 1
            
            if record['threat_level'] in data['threat_levels']:
                data['threat_levels'][record['threat_level']] += 1
        
        # Calculate platform-specific metrics
        for platform, data in platform_data.items():
            data['report_rate'] = (data['reported_posts'] / data['total_posts']) * 100
            data['risk_score'] = (
                abs(data['avg_sentiment']) * 0.5 + 
                (data['report_rate'] / 100) * 0.5
            )
        
        self.platform_patterns = platform_data
        logger.info(f"📱 Analyzed patterns for {len(platform_data)} platforms")
    
    def ultimate_cyberbullying_analysis(self, text: str, user_context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Ultimate cyberbullying analysis using all available techniques"""
        if not self.dataset:
            logger.warning("No dataset available for analysis")
            return {
                'is_cyberbullying': False, 
                'confidence': 0.0, 
                'error': 'Dataset not loaded'
            }
        
        # Check cache
        cache_key = hashlib.md5(text.lower().encode()).hexdigest()[:16]
        if cache_key in self.analysis_cache:
            cached_result = self.analysis_cache[cache_key]
            logger.info(f"📋 Dataset cache hit for text: {text[:30]}...")
            return cached_result
        
        text_lower = text.lower()
        text_words = set(text_lower.split())
        
        # Multi-method analysis
        analysis_methods = {}
        
        # Method 1: Direct dataset similarity matching
        analysis_methods['dataset_matching'] = self._analyze_against_dataset(text, text_words)
        
        # Method 2: Advanced pattern library analysis
        analysis_methods['pattern_analysis'] = self._analyze_against_patterns(text_words, text)
        
        # Method 3: Sentiment and toxicity estimation
        analysis_methods['sentiment_analysis'] = self._estimate_sentiment_toxicity(text_words, text)
        
        # Method 4: Threat level assessment
        analysis_methods['threat_assessment'] = self._assess_comprehensive_threat(text, text_words)
        
        # Method 5: Platform-specific analysis (if context available)
        analysis_methods['platform_analysis'] = self._platform_specific_analysis(
            text, user_context.get('platform', 'unknown') if user_context else 'unknown'
        )
        
        # Weighted combination of all methods
        method_weights = {
            'dataset_matching': 0.35,
            'pattern_analysis': 0.25,
            'sentiment_analysis': 0.15,
            'threat_assessment': 0.15,
            'platform_analysis': 0.10
        }
        
        combined_confidence = sum(
            analysis_methods[method]['confidence'] * weight
            for method, weight in method_weights.items()
            if analysis_methods[method]['confidence'] is not None
        )
        
        # Determine final classification
        is_cyberbullying = combined_confidence > 0.4
        
        # Determine severity level
        if combined_confidence > 0.8:
            severity = 'critical'
        elif combined_confidence > 0.6:
            severity = 'high'
        elif combined_confidence > 0.4:
            severity = 'medium'
        else:
            severity = 'low'
        
        # Generate comprehensive result
        result = {
            'is_cyberbullying': is_cyberbullying,
            'confidence': combined_confidence,
            'severity': severity,
            'analysis_methods': analysis_methods,
            'risk_factors': self._extract_risk_factors(analysis_methods),
            'recommendation': self._get_detailed_recommendation(combined_confidence, analysis_methods),
            'intervention_priority': self._get_intervention_priority(severity, analysis_methods),
            'evidence_summary': self._create_evidence_summary(analysis_methods),
            'next_steps': self._generate_next_steps(severity, is_cyberbullying),
            'analysis_metadata': {
                'text_length': len(text),
                'word_count': len(text_words),
                'methods_used': list(analysis_methods.keys()),
                'processing_timestamp': datetime.now().isoformat(),
                'dataset_size': len(self.dataset)
            }
        }
        
        # Cache result
        self.analysis_cache[cache_key] = result
        
        logger.info(f"🔍 Cyberbullying analysis: {severity.upper()} risk - {combined_confidence:.0%} confidence")
        return result
    
    def _analyze_against_dataset(self, text: str, text_words: set) -> Dict[str, Any]:
        """Advanced analysis against your actual dataset records"""
        matches = []
        high_confidence_matches = 0
        similarity_scores = []
        
        # Sample from dataset for performance (analyze against most relevant records)
        relevant_records = self._get_relevant_records(text_words)
        
        for record in relevant_records:
            content = record['text_content'].lower()
            content_words = set(content.split())
            
            # Advanced similarity calculation
            similarity_metrics = self._calculate_advanced_similarity(
                text_words, content_words, text, record
            )
            
            weighted_similarity = similarity_metrics['weighted_similarity']
            
            if weighted_similarity > 0.25:
                match_info = {
                    'content': record['text_content'][:100],
                    'similarity': weighted_similarity,
                    'sentiment': record['sentiment_score'],
                    'reported': record['reported_flag'],
                    'frequency': record['reporting_frequency'],
                    'platform': record['content_type'],
                    'threat_level': record['threat_level'],
                    'similarity_breakdown': similarity_metrics,
                    'record_metadata': {
                        'word_count': record['word_count'],
                        'target_personal': record['target_personal']
                    }
                }
                matches.append(match_info)
                similarity_scores.append(weighted_similarity)
                
                if weighted_similarity > 0.6:
                    high_confidence_matches += 1
        
        # Sort by similarity
        matches.sort(key=lambda x: x['similarity'], reverse=True)
        
        # Calculate confidence based on matches
        confidence = 0.0
        if matches:
            # Base confidence from best match
            base_confidence = matches[0]['similarity'] * 0.4
            
            # Boost from multiple matches
            match_boost = min(len(matches) * 0.1, 0.3)
            
            # Boost from high-confidence matches
            high_conf_boost = min(high_confidence_matches * 0.15, 0.25)
            
            # Average similarity boost
            avg_similarity = sum(similarity_scores) / len(similarity_scores)
            avg_boost = avg_similarity * 0.1
            
            confidence = min(base_confidence + match_boost + high_conf_boost + avg_boost, 0.95)
        
        return {
            'confidence': confidence,
            'matches': matches[:5],  # Top 5 matches
            'total_matches': len(matches),
            'high_confidence_matches': high_confidence_matches,
            'avg_similarity': sum(similarity_scores) / len(similarity_scores) if similarity_scores else 0,
            'dataset_coverage': len(relevant_records) / len(self.dataset) if self.dataset else 0
        }
    
    def _get_relevant_records(self, query_words: set, max_records: int = 150) -> List[Dict[str, Any]]:
        """Get most relevant records from dataset for analysis"""
        scored_records = []
        
        for record in self.dataset:
            content_words = set(record['text_content'].lower().split())
            overlap = len(query_words & content_words)
            
            if overlap > 0:
                # Score based on overlap and record characteristics
                score = overlap
                
                # Boost for reported content
                if record['reported_flag'] == 'Yes':
                    score *= 1.5
                
                # Boost for negative sentiment
                if record['sentiment_score'] < -0.5:
                    score *= 1.3
                
                # Boost for high threat level
                if record['threat_level'] in ['critical', 'high']:
                    score *= 1.2
                
                scored_records.append((score, record))
        
        # Sort by score and return top records
        scored_records.sort(key=lambda x: x[0], reverse=True)
        return [record for score, record in scored_records[:max_records]]
    
    def _calculate_advanced_similarity(self, text_words: set, content_words: set, 
                                     text: str, record: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate advanced similarity metrics"""
        # Basic Jaccard similarity
        intersection = text_words & content_words
        union = text_words | content_words
        jaccard = len(intersection) / len(union) if union else 0
        
        # Weighted similarity based on word importance
        important_words = intersection & {'hate', 'kill', 'stupid', 'ugly', 'loser', 'die', 'hurt'}
        importance_weight = len(important_words) * 0.3
        
        # Sentiment alignment
        text_sentiment_est = self._estimate_text_sentiment(text)
        sentiment_similarity = 1 - abs(text_sentiment_est - record['sentiment_score'])
        
        # Length similarity
        text_length = len(text)
        record_length = record['text_length']
        length_similarity = 1 - abs(text_length - record_length) / max(text_length, record_length)
        
        # Personal attack pattern similarity
        text_personal = self._detect_personal_attacks(text)
        record_personal = record['target_personal']
        personal_match = 1.0 if text_personal == record_personal else 0.5
        
        # Combine all similarity factors
        weighted_similarity = (
            jaccard * 0.4 +
            importance_weight * 0.25 +
            sentiment_similarity * 0.15 +
            length_similarity * 0.1 +
            personal_match * 0.1
        )
        
        return {
            'jaccard_similarity': jaccard,
            'importance_weight': importance_weight,
            'sentiment_similarity': sentiment_similarity,
            'length_similarity': length_similarity,
            'personal_attack_match': personal_match,
            'weighted_similarity': min(weighted_similarity, 1.0),
            'common_words': list(intersection)
        }
    
    def _estimate_text_sentiment(self, text: str) -> float:
        """Estimate sentiment of text using simple lexicon approach"""
        positive_words = {
            'good', 'great', 'awesome', 'amazing', 'excellent', 'wonderful',
            'nice', 'love', 'happy', 'joy', 'fantastic', 'brilliant'
        }
        negative_words = {
            'hate', 'stupid', 'ugly', 'terrible', 'awful', 'horrible',
            'dumb', 'worthless', 'pathetic', 'loser', 'idiot', 'disgusting'
        }
        
        words = set(text.lower().split())
        positive_count = len(words & positive_words)
        negative_count = len(words & negative_words)
        
        if positive_count + negative_count == 0:
            return 0.0
        
        sentiment = (positive_count - negative_count) / (positive_count + negative_count)
        return sentiment
    
    def _analyze_against_patterns(self, text_words: set, full_text: str) -> Dict[str, Any]:
        """Advanced pattern analysis using built library"""
        harmful_score = 0.0
        detected_patterns = []
        pattern_categories = {'high_risk': 0, 'medium_risk': 0, 'low_risk': 0}
        
        for word in text_words:
            if word in self.pattern_library:
                pattern_data = self.pattern_library[word]
                
                # Calculate word-level harmfulness score
                sentiment_factor = abs(pattern_data['avg_sentiment']) if pattern_data['avg_sentiment'] < 0 else 0
                report_factor = pattern_data['report_rate']
                frequency_factor = min(pattern_data['frequency'] / 50, 1.0)  # Normalize frequency
                
                word_score = (
                    sentiment_factor * 0.5 +
                    report_factor * 0.3 +
                    frequency_factor * 0.2
                )
                
                harmful_score += word_score
                
                # Categorize pattern risk
                if word_score > 0.7:
                    pattern_categories['high_risk'] += 1
                elif word_score > 0.4:
                    pattern_categories['medium_risk'] += 1
                else:
                    pattern_categories['low_risk'] += 1
                
                detected_patterns.append({
                    'word': word,
                    'harmfulness_score': word_score,
                    'frequency_in_dataset': pattern_data['frequency'],
                    'avg_sentiment': pattern_data['avg_sentiment'],
                    'report_rate': pattern_data['report_rate'],
                    'threat_associations': pattern_data['threat_associations'],
                    'platforms_seen': pattern_data['platforms']
                })
        
        # Calculate overall confidence
        word_count = len(text_words)
        confidence = min(harmful_score / max(word_count, 1), 1.0)
        
        # Apply pattern category weighting
        if pattern_categories['high_risk'] > 0:
            confidence *= 1.2
        elif pattern_categories['medium_risk'] > pattern_categories['low_risk']:
            confidence *= 1.1
        
        confidence = min(confidence, 1.0)
        
        return {
            'confidence': confidence,
            'harmful_score': harmful_score,
            'detected_patterns': detected_patterns,
            'pattern_categories': pattern_categories,
            'pattern_density': len(detected_patterns) / max(word_count, 1),
            'highest_risk_word': max(detected_patterns, key=lambda x: x['harmfulness_score']) if detected_patterns else None
        }
    
    def _estimate_sentiment_toxicity(self, text_words: set, full_text: str) -> Dict[str, Any]:
        """Enhanced sentiment and toxicity estimation"""
        # Enhanced word lists based on dataset analysis
        highly_negative = {
            'hate', 'kill', 'die', 'stupid', 'ugly', 'worthless', 'pathetic',
            'loser', 'idiot', 'disgusting', 'horrible', 'terrible', 'awful'
        }
        moderately_negative = {
            'dumb', 'weird', 'annoying', 'gross', 'boring', 'lame', 'mean'
        }
        positive = {
            'good', 'great', 'awesome', 'nice', 'love', 'happy', 'amazing',
            'wonderful', 'excellent', 'fantastic', 'brilliant'
        }
        
        # Count occurrences
        highly_neg_count = len(text_words & highly_negative)
        mod_neg_count = len(text_words & moderately_negative)
        pos_count = len(text_words & positive)
        
        # Calculate weighted sentiment
        sentiment_score = (
            pos_count * 1.0 - 
            mod_neg_count * 1.5 - 
            highly_neg_count * 2.5
        ) / max(len(text_words), 1)
        
        # Toxicity indicators
        toxicity_indicators = {
            'personal_attacks': self._detect_personal_attacks(full_text),
            'threat_language': highly_neg_count > 0,
            'excessive_caps': full_text.isupper() and len(full_text) > 10,
            'repetitive_negative': any(full_text.lower().count(word) > 2 for word in highly_negative),
            'profanity_masking': self._detect_profanity_indicators(full_text) > 0
        }
        
        toxicity_score = sum(toxicity_indicators.values()) / len(toxicity_indicators)
        
        # Combine for final confidence
        confidence = abs(sentiment_score) * 0.6 + toxicity_score * 0.4
        confidence = min(confidence, 1.0)
        
        return {
            'confidence': confidence,
            'estimated_sentiment': sentiment_score,
            'toxicity_score': toxicity_score,
            'word_counts': {
                'highly_negative': highly_neg_count,
                'moderately_negative': mod_neg_count,
                'positive': pos_count
            },
            'toxicity_indicators': toxicity_indicators,
            'negative_words_found': list(text_words & (highly_negative | moderately_negative))
        }
    
    def _assess_comprehensive_threat(self, text: str, text_words: set) -> Dict[str, Any]:
        """Comprehensive threat level assessment"""
        threat_indicators = {
            'direct_threats': self._detect_direct_threats(text),
            'intimidation': self._detect_intimidation(text),
            'social_exclusion': self._detect_social_exclusion(text),
            'reputation_damage': self._detect_reputation_attacks(text),
            'identity_attacks': self._detect_identity_attacks(text)
        }
        
        # Weight different types of threats
        threat_weights = {
            'direct_threats': 1.0,
            'intimidation': 0.8,
            'identity_attacks': 0.7,
            'reputation_damage': 0.6,
            'social_exclusion': 0.5
        }
        
        weighted_threat_score = sum(
            threat_indicators[threat_type] * threat_weights[threat_type]
            for threat_type in threat_indicators
        ) / len(threat_indicators)
        
        # Determine threat category
        if weighted_threat_score > 0.8:
            threat_category = 'severe'
        elif weighted_threat_score > 0.6:
            threat_category = 'high'
        elif weighted_threat_score > 0.3:
            threat_category = 'moderate'
        else:
            threat_category = 'low'
        
        return {
            'confidence': weighted_threat_score,
            'threat_category': threat_category,
            'threat_indicators': threat_indicators,
            'primary_threat_type': max(threat_indicators.items(), key=lambda x: x[1])[0],
            'threat_score_breakdown': {
                threat_type: score * weight 
                for threat_type, (score, weight) in zip(threat_indicators.keys(), 
                                                       zip(threat_indicators.values(), threat_weights.values()))
            }
        }
    
    def _detect_direct_threats(self, text: str) -> float:
        """Detect direct threats in text"""
        threat_patterns = [
            r'\bkill\s+yourself?\b',
            r'\bgo\s+die\b',
            r'\bhurt\s+you\b',
            r'\bmake\s+you\s+pay\b',
            r'\bwatch\s+out\b'
        ]
        
        import re
        threat_count = sum(1 for pattern in threat_patterns if re.search(pattern, text.lower()))
        return min(threat_count * 0.5, 1.0)
    
    def _detect_intimidation(self, text: str) -> float:
        """Detect intimidation tactics"""
        intimidation_words = {'scared', 'fear', 'regret', 'sorry', 'consequences', 'trouble'}
        text_words = set(text.lower().split())
        intimidation_count = len(text_words & intimidation_words)
        return min(intimidation_count * 0.3, 1.0)
    
    def _detect_social_exclusion(self, text: str) -> float:
        """Detect social exclusion language"""
        exclusion_phrases = [
            'nobody likes you', 'no friends', 'alone forever', 'everyone hates',
            'dont belong', 'not wanted', 'go away'
        ]
        text_lower = text.lower()
        exclusion_count = sum(1 for phrase in exclusion_phrases if phrase in text_lower)
        return min(exclusion_count * 0.4, 1.0)
    
    def _detect_reputation_attacks(self, text: str) -> float:
        """Detect attacks on reputation"""
        reputation_words = {'embarrassing', 'humiliating', 'shame', 'expose', 'reveal', 'tell everyone'}
        text_lower = text.lower()
        reputation_count = sum(1 for word in reputation_words if word in text_lower)
        return min(reputation_count * 0.3, 1.0)
    
    def _detect_identity_attacks(self, text: str) -> float:
        """Detect attacks on identity/characteristics"""
        identity_words = {'ugly', 'fat', 'stupid', 'weird', 'freak', 'loser', 'worthless'}
        text_words = set(text.lower().split())
        identity_count = len(text_words & identity_words)
        return min(identity_count * 0.4, 1.0)
    
    def _platform_specific_analysis(self, text: str, platform: str) -> Dict[str, Any]:
        """Platform-specific cyberbullying analysis"""
        if platform not in self.platform_patterns:
            return {'confidence': 0.0, 'platform_known': False}
        
        platform_data = self.platform_patterns[platform]
        
        # Compare against platform norms
        text_sentiment = self._estimate_text_sentiment(text)
        platform_avg_sentiment = platform_data['avg_sentiment']
        
        # Risk assessment based on platform patterns
        sentiment_deviation = abs(text_sentiment - platform_avg_sentiment)
        platform_risk = platform_data['risk_score']
        
        confidence = min(sentiment_deviation * platform_risk, 1.0)
        
        return {
            'confidence': confidence,
            'platform_known': True,
            'platform_risk_score': platform_risk,
            'platform_stats': {
                'total_posts': platform_data['total_posts'],
                'report_rate': platform_data['report_rate'],
                'avg_sentiment': platform_avg_sentiment
            },
            'text_vs_platform': {
                'sentiment_deviation': sentiment_deviation,
                'risk_relative_to_platform': confidence
            }
        }
    
    def _extract_risk_factors(self, analysis_methods: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Extract key risk factors from analysis"""
        risk_factors = []
        
        # From dataset matching
        dataset_results = analysis_methods.get('dataset_matching', {})
        if dataset_results.get('high_confidence_matches', 0) > 0:
            risk_factors.append({
                'factor': 'High similarity to reported cyberbullying cases',
                'severity': 'high',
                'evidence': f"{dataset_results['high_confidence_matches']} high-confidence matches found"
            })
        
        # From pattern analysis
        pattern_results = analysis_methods.get('pattern_analysis', {})
        if pattern_results.get('pattern_categories', {}).get('high_risk', 0) > 0:
            risk_factors.append({
                'factor': 'Contains high-risk language patterns',
                'severity': 'high',
                'evidence': f"{pattern_results['pattern_categories']['high_risk']} high-risk words detected"
            })
        
        # From threat assessment
        threat_results = analysis_methods.get('threat_assessment', {})
        if threat_results.get('threat_category') in ['severe', 'high']:
            risk_factors.append({
                'factor': f"Contains {threat_results['threat_category']} threat indicators",
                'severity': threat_results['threat_category'],
                'evidence': f"Primary threat type: {threat_results.get('primary_threat_type', 'unknown')}"
            })
        
        return risk_factors
    
    def _get_detailed_recommendation(self, confidence: float, analysis_methods: Dict[str, Any]) -> str:
        """Generate detailed recommendation based on analysis"""
        if confidence > 0.8:
            return "CRITICAL INTERVENTION REQUIRED: This appears to be severe cyberbullying. Immediate documentation, reporting, blocking, and adult notification essential. Consider crisis support resources."
        elif confidence > 0.6:
            return "HIGH PRIORITY RESPONSE: Strong indicators of cyberbullying detected. Document evidence, report to platform, block perpetrator, and inform trusted adults promptly."
        elif confidence > 0.4:
            return "MODERATE CONCERN: Potential cyberbullying indicators present. Monitor situation closely, document interactions, consider preventive blocking, and discuss with trusted adults."
        elif confidence > 0.2:
            return "LOW RISK MONITORING: Some concerning language detected. Maintain awareness, use privacy settings, and be prepared to escalate if behavior continues."
        else:
            return "MINIMAL RISK: Content appears to be within normal interaction range. Continue standard online safety practices."
    
    def _get_intervention_priority(self, severity: str, analysis_methods: Dict[str, Any]) -> str:
        """Determine intervention priority level"""
        priority_mapping = {
            'critical': 'IMMEDIATE',
            'high': 'URGENT', 
            'medium': 'PROMPT',
            'low': 'ROUTINE'
        }
        
        base_priority = priority_mapping.get(severity, 'ROUTINE')
        
        # Escalate based on specific factors
        threat_results = analysis_methods.get('threat_assessment', {})
        if threat_results.get('primary_threat_type') == 'direct_threats':
            return 'IMMEDIATE'
        
        dataset_results = analysis_methods.get('dataset_matching', {})
        if dataset_results.get('high_confidence_matches', 0) > 3:
            return 'URGENT'
        
        return base_priority
    
    def _create_evidence_summary(self, analysis_methods: Dict[str, Any]) -> Dict[str, Any]:
        """Create comprehensive evidence summary"""
        evidence = {
            'dataset_evidence': [],
            'pattern_evidence': [],
            'sentiment_evidence': [],
            'threat_evidence': []
        }
        
        # Dataset evidence
        dataset_results = analysis_methods.get('dataset_matching', {})
        if dataset_results.get('matches'):
            for match in dataset_results['matches'][:3]:
                evidence['dataset_evidence'].append(f"Similar to reported case: {match['similarity']:.0%} match")
        
        # Pattern evidence  
        pattern_results = analysis_methods.get('pattern_analysis', {})
        if pattern_results.get('detected_patterns'):
            for pattern in pattern_results['detected_patterns'][:3]:
                evidence['pattern_evidence'].append(f"Harmful word '{pattern['word']}': {pattern['harmfulness_score']:.0%} risk")
        
        # Sentiment evidence
        sentiment_results = analysis_methods.get('sentiment_analysis', {})
        if sentiment_results.get('negative_words_found'):
            evidence['sentiment_evidence'].append(f"Negative language detected: {len(sentiment_results['negative_words_found'])} harmful words")
        
        # Threat evidence
        threat_results = analysis_methods.get('threat_assessment', {})
        threat_indicators = threat_results.get('threat_indicators', {})
        active_threats = [threat for threat, active in threat_indicators.items() if active > 0.5]
        if active_threats:
            evidence['threat_evidence'].append(f"Threat types detected: {', '.join(active_threats)}")
        
        return evidence
    
    def _generate_next_steps(self, severity: str, is_cyberbullying: bool) -> List[str]:
        """Generate specific next steps based on analysis"""
        if not is_cyberbullying:
            return [
                "Continue monitoring for concerning patterns",
                "Maintain standard online safety practices",
                "Build positive online relationships"
            ]
        
        steps = []
        
        if severity in ['critical', 'high']:
            steps.extend([
                "🚨 IMMEDIATE: Take screenshots of all evidence",
                "🚫 IMMEDIATE: Block the perpetrator(s) on all platforms",
                "📞 IMMEDIATE: Inform trusted adults (parents, teachers, counselors)",
                "📋 IMMEDIATE: Report to platform using official channels",
                "🏥 URGENT: Consider crisis support if feeling overwhelmed"
            ])
        elif severity == 'medium':
            steps.extend([
                "📸 Document the concerning behavior with screenshots",
                "🚫 Block or restrict the person's access to you",
                "👥 Discuss with trusted adults about the situation",
                "📋 Report to the platform if behavior continues",
                "🛡️ Strengthen privacy settings on all accounts"
            ])
        else:  # low severity
            steps.extend([
                "👀 Monitor the situation for escalation",
                "🔒 Review and update privacy settings",
                "👥 Discuss with friends or family if concerned",
                "📱 Consider blocking if behavior continues"
            ])
        
        return steps
    
    def _calculate_comprehensive_stats(self):
        """Calculate comprehensive dataset statistics"""
        if not self.dataset:
            return
        
        total = len(self.dataset)
        
        # Basic counts
        negative_sentiment = sum(1 for r in self.dataset if r['sentiment_score'] < -0.3)
        reported = sum(1 for r in self.dataset if r['reported_flag'] == 'Yes')
        high_risk = sum(1 for r in self.dataset if r['threat_level'] in ['critical', 'high'])
        
        # Platform distribution
        platforms = {}
        threat_levels = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0}
        sentiment_ranges = {'very_negative': 0, 'negative': 0, 'neutral': 0, 'positive': 0}
        
        for record in self.dataset:
            # Platform stats
            platform = record['content_type']
            platforms[platform] = platforms.get(platform, 0) + 1
            
            # Threat level stats
            if record['threat_level'] in threat_levels:
                threat_levels[record['threat_level']] += 1
            
            # Sentiment distribution
            sentiment = record['sentiment_score']
            if sentiment < -0.7:
                sentiment_ranges['very_negative'] += 1
            elif sentiment < -0.3:
                sentiment_ranges['negative'] += 1
            elif sentiment < 0.3:
                sentiment_ranges['neutral'] += 1
            else:
                sentiment_ranges['positive'] += 1
        
        # Advanced metrics
        personal_attacks = sum(1 for r in self.dataset if r['target_personal'])
        avg_length = sum(r['text_length'] for r in self.dataset) / total
        avg_word_count = sum(r['word_count'] for r in self.dataset) / total
        
        self.stats = {
            'dataset_overview': {
                'total_records': total,
                'processing_date': datetime.now().isoformat(),
                'data_quality': 'high' if total > 100 else 'medium'
            },
            'content_analysis': {
                'negative_sentiment_count': negative_sentiment,
                'negative_sentiment_percentage': (negative_sentiment / total) * 100,
                'reported_content_count': reported,
                'reported_percentage': (reported / total) * 100,
                'high_risk_content': high_risk,
                'high_risk_percentage': (high_risk / total) * 100,
                'personal_attacks': personal_attacks,
                'personal_attack_percentage': (personal_attacks / total) * 100
            },
            'sentiment_distribution': {
                'average_sentiment': sum(r['sentiment_score'] for r in self.dataset) / total,
                'sentiment_ranges': sentiment_ranges,
                'sentiment_std': self._calculate_std([r['sentiment_score'] for r in self.dataset])
            },
            'platform_analysis': {
                'platform_distribution': platforms,
                'platform_count': len(platforms),
                'most_problematic_platform': max(platforms.items(), key=lambda x: x[1])[0] if platforms else 'unknown'
            },
            'threat_analysis': {
                'threat_level_distribution': threat_levels,
                'critical_high_percentage': ((threat_levels['critical'] + threat_levels['high']) / total) * 100
            },
            'content_characteristics': {
                'average_text_length': avg_length,
                'average_word_count': avg_word_count,
                'total_reporting_events': sum(r['reporting_frequency'] for r in self.dataset)
            }
        }
    
    def _calculate_std(self, values: List[float]) -> float:
        """Calculate standard deviation"""
        if not values:
            return 0.0
        
        mean = sum(values) / len(values)
        variance = sum((x - mean) ** 2 for x in values) / len(values)
        return variance ** 0.5
    
    def _create_comprehensive_sample_data(self):
        """Create comprehensive sample data if CSV not available"""
        sample_data = [
            {
                'text_content': 'you are so stupid and ugly nobody likes you at all',
                'sentiment_score': -0.95,
                'reported_flag': 'Yes',
                'reporting_frequency': 8,
                'content_type': 'Instagram',
                'engagement_metrics': '0 likes, 0 shares, 5 comments',
                'user_metadata': 'Age: 16, Gender: Unknown, Location: US',
                'image_content': 'None',
                'video_content': 'None',
                'interaction_type': 'public_comment',
                'word_count': 10,
                'contains_caps': False,
                'exclamation_count': 0,
                'question_count': 0,
                'profanity_indicators': 0,
                'threat_level': 'high',
                'target_personal': True,
                'processed_timestamp': datetime.now().isoformat()
            },
            {
                'text_content': 'kill yourself loser everyone hates you anyway pathetic',
                'sentiment_score': -0.98,
                'reported_flag': 'Yes', 
                'reporting_frequency': 12,
                'content_type': 'TikTok',
                'engagement_metrics': '0 likes, 0 shares, 2 comments',
                'user_metadata': 'Age: 15, Gender: Male, Location: Canada',
                'image_content': 'None',
                'video_content': 'None',
                'interaction_type': 'direct_message',
                'word_count': 8,
                'contains_caps': False,
                'exclamation_count': 0,
                'question_count': 0,
                'profanity_indicators': 0,
                'threat_level': 'critical',
                'target_personal': True,
                'processed_timestamp': datetime.now().isoformat()
            }
        ]
        
        # Convert to full dataset format
        for i, record in enumerate(sample_data):
            record['text_length'] = len(record['text_content'])
        
        self.dataset = sample_data
        logger.info(f"⚠️ Using enhanced sample data: {len(self.dataset)} records")
        self._calculate_comprehensive_stats()
    
    def get_dataset_insights(self) -> Dict[str, Any]:
        """Get comprehensive insights from the dataset"""
        if not self.stats:
            return {'error': 'No statistics available'}
        
        insights = {
            'key_findings': [],
            'platform_insights': [],
            'risk_patterns': [],
            'recommendations': []
        }
        
        # Key findings
        stats = self.stats
        high_risk_pct = stats['content_analysis']['high_risk_percentage']
        report_pct = stats['content_analysis']['reported_percentage']
        
        if high_risk_pct > 20:
            insights['key_findings'].append(f"High proportion of critical/high-risk content: {high_risk_pct:.1f}%")
        
        if report_pct > 15:
            insights['key_findings'].append(f"Significant user reporting activity: {report_pct:.1f}%")
        
        # Platform insights
        platform_dist = stats['platform_analysis']['platform_distribution']
        most_problematic = stats['platform_analysis']['most_problematic_platform']
        
        insights['platform_insights'].append(f"Most active platform for incidents: {most_problematic}")
        insights['platform_insights'].append(f"Platform diversity: {len(platform_dist)} different platforms")
        
        # Risk patterns
        personal_attack_pct = stats['content_analysis']['personal_attack_percentage']
        if personal_attack_pct > 25:
            insights['risk_patterns'].append(f"High rate of personal attacks: {personal_attack_pct:.1f}%")
        
        # Recommendations
        insights['recommendations'].extend([
            "Implement real-time monitoring for high-risk language patterns",
            "Focus intervention efforts on platforms with highest incident rates",
            "Develop platform-specific response strategies",
            "Create early warning system for escalating situations"
        ])
        
        return insights