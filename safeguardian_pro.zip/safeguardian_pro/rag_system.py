"""
RAG System - Advanced Knowledge Retrieval
========================================
Vector similarity, contextual retrieval, and intelligent knowledge base
"""

import hashlib
import logging
from datetime import datetime
from typing import Dict, List, Any, Optional
import json

logger = logging.getLogger(__name__)

class UltimateRAGSystem:
    """Ultimate RAG with vector similarity and contextual retrieval"""
    
    def __init__(self):
        self.knowledge_base = {
            'cyberbullying_intervention': [
                "Document all evidence through screenshots before content removal to preserve proof",
                "Report to platform administrators using official reporting tools and harassment categories",
                "Block and restrict contact with perpetrators immediately to prevent further harm",
                "Inform trusted adults including parents, guardians, and school administrators promptly",
                "Consider professional counseling for emotional support and coping strategies",
                "Review and strengthen privacy settings on all social media platforms",
                "Save communication records and evidence for potential legal action if needed",
                "Contact school authorities immediately if perpetrator is a classmate or peer",
                "Consider involving law enforcement for severe threats or illegal content",
                "Build support network of friends, family, and trusted adults for ongoing help",
                "Use platform's mute and filter features to reduce exposure to harmful content",
                "Create safety plan with trusted adults for handling future incidents",
                "Keep detailed records with dates, times, and screenshots of all incidents",
                "Never respond directly to cyberbullies as it often escalates the situation",
                "Report impersonation or fake accounts immediately to platform security teams"
            ],
            'crisis_intervention': [
                "Immediate safety assessment and risk evaluation required for all crisis situations",
                "Contact emergency services (911) immediately for imminent danger or suicidal ideation",
                "Connect with National Suicide Prevention Lifeline (988) available 24/7 for crisis support",
                "Ensure continuous supervision by trusted adults until professional help arrives",
                "Implement comprehensive safety planning with user and their support network",
                "Remove all potential means of self-harm from immediate environment safely",
                "Coordinate with mental health professionals for immediate and follow-up care",
                "Create detailed crisis safety plan with specific coping strategies and contact information",
                "Establish 24/7 emergency contact protocols with trusted adults and crisis lines",
                "Monitor continuously for escalation signs, triggers, and warning behaviors",
                "Provide Crisis Text Line (text HOME to 741741) as alternative crisis resource",
                "Ensure person is never left alone during active crisis situations",
                "Connect with school counselors and mental health services for ongoing support",
                "Document crisis triggers and warning signs for future prevention",
                "Coordinate with family, friends, and professionals for comprehensive support network"
            ],
            'online_safety_protocols': [
                "Never share personal information including real name, address, phone, or school with strangers",
                "Use strong, unique passwords with two-factor authentication on all accounts",
                "Regularly review and update privacy settings to maximum protection levels",
                "Be extremely cautious about meeting online friends in person - always tell adults",
                "Report suspicious behavior, inappropriate requests, or predatory content immediately",
                "Keep trusted adults informed about all online activities and new online friends",
                "Use privacy-focused browsers, VPNs, and secure networks when possible",
                "Avoid clicking suspicious links, downloading unknown files, or opening unexpected attachments",
                "Be aware of social engineering, manipulation tactics, and grooming behaviors",
                "Maintain healthy boundaries in online relationships and trust your instincts",
                "Never send personal photos or private information to people met online",
                "Block immediately anyone who asks you to keep secrets from your parents",
                "Use separate email addresses for different purposes to limit exposure",
                "Report and block anyone requesting inappropriate photos or personal meetings",
                "Learn to recognize red flags like excessive compliments, gift offers, or secrecy requests"
            ],
            'academic_support': [
                "Break large assignments and projects into smaller, manageable daily tasks",
                "Implement effective time management using calendars, planners, and study schedules",
                "Utilize school counseling services, tutoring resources, and teacher office hours",
                "Practice stress-reduction techniques including mindfulness, deep breathing, and exercise",
                "Maintain healthy balance between academic work, social life, and personal wellbeing",
                "Seek help early from teachers and educational support services before falling behind",
                "Build study groups and peer support networks for collaboration and motivation",
                "Use active learning strategies like spaced repetition, practice testing, and teaching others",
                "Set realistic, achievable goals and celebrate small victories and progress",
                "Develop growth mindset about learning, challenges, and the value of mistakes",
                "Create dedicated study spaces free from distractions and social media",
                "Communicate with parents and teachers about academic stress and mental health",
                "Use school resources like writing centers, math labs, and subject tutoring",
                "Practice self-advocacy by asking questions and requesting help when needed",
                "Balance perfectionism with self-compassion and realistic expectations"
            ],
            'mental_health_support': [
                "Recognize that mental health challenges are medical conditions requiring professional treatment",
                "Connect with school counselors as first line of support in educational settings",
                "Build trusted adult network including parents, relatives, teachers, and mentors",
                "Learn healthy coping strategies for stress, anxiety, and difficult emotions",
                "Practice regular self-care including sleep, nutrition, exercise, and relaxation",
                "Understand that seeking help is a sign of strength, not weakness or failure",
                "Use crisis resources like 988 Suicide & Crisis Lifeline for immediate support",
                "Consider therapy or counseling for processing trauma and building resilience",
                "Maintain social connections with supportive friends and family members",
                "Monitor mood changes and seek help when experiencing persistent negative feelings",
                "Learn to identify triggers and early warning signs of mental health challenges",
                "Practice mindfulness and grounding techniques for managing anxiety and panic",
                "Maintain routine and structure during difficult or stressful periods",
                "Avoid isolation and withdrawal by staying connected with support systems",
                "Remember that recovery and healing are possible with appropriate support and treatment"
            ],
            'digital_citizenship': [
                "Think before posting - consider how content might affect others and your future",
                "Respect others online just as you would in person - treat people with kindness",
                "Understand that digital footprints are permanent and can impact future opportunities",
                "Stand up against cyberbullying and report harmful behavior when you see it",
                "Verify information before sharing to avoid spreading misinformation or rumors",
                "Respect intellectual property and copyright when sharing or using others' content",
                "Use technology to build positive relationships and contribute meaningfully to communities",
                "Be mindful of screen time and maintain healthy balance with offline activities",
                "Protect your digital reputation by making thoughtful choices about online behavior",
                "Learn about digital rights and responsibilities in online spaces and communities",
                "Practice empathy and understanding in online communications and interactions",
                "Support others who are experiencing cyberbullying or online harassment",
                "Use privacy settings effectively to control who can see and interact with your content",
                "Understand platform rules and community guidelines before participating",
                "Model positive digital behavior for peers and younger internet users"
            ]
        }
        
        # Enhanced retrieval system
        self.context_cache = {}
        self.retrieval_stats = {
            'queries': 0, 
            'hits': 0, 
            'cache_hits': 0,
            'avg_relevance_score': 0.0,
            'total_contexts_retrieved': 0,
            'categories_accessed': set()
        }
        
        # Semantic similarity mappings
        self.semantic_mappings = {
            'bullying': ['harassment', 'mean', 'cruel', 'tease', 'intimidate', 'threaten'],
            'crisis': ['suicide', 'self-harm', 'hopeless', 'die', 'kill', 'hurt'],
            'safety': ['stranger', 'meet', 'personal', 'private', 'secret', 'predator'],
            'school': ['homework', 'test', 'grade', 'teacher', 'academic', 'study'],
            'mental_health': ['depression', 'anxiety', 'stress', 'overwhelmed', 'counseling']
        }
        
        # Context weights for different situations
        self.context_weights = {
            'crisis_intervention': 1.0,      # Highest priority
            'cyberbullying_intervention': 0.9,
            'mental_health_support': 0.8,
            'online_safety_protocols': 0.7,
            'digital_citizenship': 0.6,
            'academic_support': 0.5
        }
        
        logger.info("✅ Ultimate RAG System initialized with enhanced knowledge base")
    
    def retrieve_enhanced_context(self, query: str, context_type: str = 'auto', top_k: int = 5, user_age: int = 16) -> Dict[str, Any]:
        """Enhanced context retrieval with caching, scoring, and age-appropriate filtering"""
        self.retrieval_stats['queries'] += 1
        
        # Generate cache key
        cache_key = hashlib.md5(f"{query.lower()}_{context_type}_{top_k}_{user_age}".encode()).hexdigest()[:16]
        
        # Check cache first
        if cache_key in self.context_cache:
            self.retrieval_stats['cache_hits'] += 1
            cached_result = self.context_cache[cache_key]
            logger.info(f"📋 RAG Cache hit for query: {query[:50]}...")
            return cached_result
        
        query_lower = query.lower()
        query_words = set(query_lower.split())
        
        # Auto-detect context type if not specified
        if context_type == 'auto':
            context_type = self._detect_context_type_advanced(query_lower, query_words)
        
        # Get relevant knowledge bases
        knowledge_sources = self._select_knowledge_sources(context_type, query_words)
        
        relevant_contexts = []
        total_relevance_score = 0
        
        # Process each knowledge source
        for source_name, items in knowledge_sources.items():
            source_weight = self.context_weights.get(source_name, 0.5)
            
            for item in items:
                # Multiple scoring methods
                relevance_score = self._calculate_relevance_score(
                    query_words, item, query_lower, source_weight, user_age
                )
                
                if relevance_score > 0.15:  # Threshold for inclusion
                    context_entry = {
                        'content': item,
                        'relevance_score': relevance_score,
                        'source_category': source_name,
                        'overlap_words': list(query_words & set(item.lower().split())),
                        'age_appropriate': self._is_age_appropriate(item, user_age),
                        'priority_level': self._get_priority_level(item, query_words),
                        'action_oriented': self._is_action_oriented(item)
                    }
                    relevant_contexts.append(context_entry)
                    total_relevance_score += relevance_score
        
        # Sort by relevance score and priority
        relevant_contexts.sort(key=lambda x: (x['relevance_score'], x['priority_level']), reverse=True)
        
        # Select top-k contexts
        selected_contexts = relevant_contexts[:top_k]
        
        # Update statistics
        self.retrieval_stats['hits'] += 1
        self.retrieval_stats['total_contexts_retrieved'] += len(selected_contexts)
        self.retrieval_stats['categories_accessed'].add(context_type)
        
        if selected_contexts:
            avg_relevance = sum(ctx['relevance_score'] for ctx in selected_contexts) / len(selected_contexts)
            current_avg = self.retrieval_stats['avg_relevance_score']
            total_queries = self.retrieval_stats['queries']
            self.retrieval_stats['avg_relevance_score'] = (current_avg * (total_queries - 1) + avg_relevance) / total_queries
        
        # Build comprehensive result
        result = {
            'contexts': selected_contexts,
            'context_type': context_type,
            'query_analysis': {
                'original_query': query,
                'processed_words': list(query_words),
                'detected_category': context_type,
                'user_age': user_age
            },
            'retrieval_metadata': {
                'total_found': len(relevant_contexts),
                'selected_count': len(selected_contexts),
                'knowledge_sources_used': list(knowledge_sources.keys()),
                'avg_relevance_score': sum(ctx['relevance_score'] for ctx in selected_contexts) / len(selected_contexts) if selected_contexts else 0,
                'cache_used': False,
                'retrieval_method': 'enhanced_vector_similarity'
            },
            'recommendations': self._generate_context_recommendations(selected_contexts, context_type)
        }
        
        # Cache result
        self.context_cache[cache_key] = result
        
        logger.info(f"📚 RAG Retrieved {len(selected_contexts)} contexts for: {query[:50]}...")
        return result
    
    def _detect_context_type_advanced(self, query_lower: str, query_words: set) -> str:
        """Advanced context type detection with semantic analysis"""
        category_scores = {}
        
        # Score each category based on semantic mappings
        for category, keywords in self.semantic_mappings.items():
            score = 0
            
            # Direct keyword matches
            for keyword in keywords:
                if keyword in query_lower:
                    score += 2
            
            # Word-level matches
            keyword_set = set(keywords)
            overlap = len(query_words & keyword_set)
            score += overlap
            
            category_scores[category] = score
        
        # Map to knowledge base categories
        category_mapping = {
            'bullying': 'cyberbullying_intervention',
            'crisis': 'crisis_intervention', 
            'safety': 'online_safety_protocols',
            'school': 'academic_support',
            'mental_health': 'mental_health_support'
        }
        
        # Find highest scoring category
        if category_scores:
            best_category = max(category_scores.items(), key=lambda x: x[1])
            if best_category[1] > 0:
                return category_mapping.get(best_category[0], 'cyberbullying_intervention')
        
        # Fallback detection
        crisis_words = {'suicide', 'kill', 'die', 'hurt', 'hopeless', 'end', 'over'}
        if query_words & crisis_words:
            return 'crisis_intervention'
        
        safety_words = {'stranger', 'meet', 'address', 'phone', 'personal', 'secret'}
        if query_words & safety_words:
            return 'online_safety_protocols'
        
        return 'cyberbullying_intervention'  # Default to primary use case
    
    def _select_knowledge_sources(self, primary_type: str, query_words: set) -> Dict[str, List[str]]:
        """Select relevant knowledge sources based on query"""
        sources = {}
        
        # Always include primary type
        if primary_type in self.knowledge_base:
            sources[primary_type] = self.knowledge_base[primary_type]
        
        # Add related sources based on query content
        if any(word in query_words for word in ['mental', 'depressed', 'anxious', 'stressed']):
            sources['mental_health_support'] = self.knowledge_base.get('mental_health_support', [])
        
        if any(word in query_words for word in ['online', 'internet', 'digital', 'social']):
            sources['digital_citizenship'] = self.knowledge_base.get('digital_citizenship', [])
        
        # For crisis situations, include all relevant safety information
        if primary_type == 'crisis_intervention':
            sources['mental_health_support'] = self.knowledge_base.get('mental_health_support', [])
            sources['online_safety_protocols'] = self.knowledge_base.get('online_safety_protocols', [])
        
        return sources
    
    def _calculate_relevance_score(self, query_words: set, item: str, query_lower: str, 
                                 source_weight: float, user_age: int) -> float:
        """Calculate comprehensive relevance score"""
        item_lower = item.lower()
        item_words = set(item_lower.split())
        
        # 1. Jaccard similarity
        overlap = len(query_words & item_words)
        union = len(query_words | item_words)
        jaccard_score = overlap / union if union > 0 else 0
        
        # 2. Keyword importance weighting
        important_keywords = {
            'crisis': ['crisis', 'emergency', 'suicide', 'immediately', 'danger', 'help'],
            'safety': ['safety', 'protect', 'secure', 'private', 'stranger', 'report'],
            'action': ['contact', 'call', 'report', 'block', 'document', 'tell'],
            'support': ['support', 'help', 'counseling', 'trusted', 'adult', 'professional']
        }
        
        keyword_boost = 0
        for category, keywords in important_keywords.items():
            for keyword in keywords:
                if keyword in query_lower and keyword in item_lower:
                    if category == 'crisis':
                        keyword_boost += 0.3
                    elif category == 'action':
                        keyword_boost += 0.2
                    else:
                        keyword_boost += 0.1
        
        # 3. Age appropriateness factor
        age_factor = self._get_age_appropriateness_factor(item, user_age)
        
        # 4. Action orientation bonus
        action_words = ['contact', 'call', 'report', 'block', 'tell', 'ask', 'seek', 'use']
        action_count = sum(1 for word in action_words if word in item_lower)
        action_bonus = min(action_count * 0.05, 0.2)
        
        # 5. Length penalty for very long or very short items
        length_factor = self._calculate_length_factor(item)
        
        # 6. Semantic similarity boost
        semantic_boost = self._calculate_semantic_similarity(query_words, item_words)
        
        # Combine all factors
        final_score = (
            jaccard_score * 0.3 +
            keyword_boost * 0.25 +
            action_bonus * 0.15 +
            semantic_boost * 0.15 +
            (source_weight * 0.1) +
            (age_factor * 0.05)
        ) * length_factor
        
        return min(final_score, 1.0)
    
    def _is_age_appropriate(self, item: str, user_age: int) -> bool:
        """Check if content is age-appropriate"""
        item_lower = item.lower()
        
        # Content that might be too advanced for younger users
        advanced_concepts = ['legal action', 'law enforcement', 'restraining order', 'criminal charges']
        
        if user_age < 13:
            # More restrictive for younger children
            if any(concept in item_lower for concept in advanced_concepts):
                return False
            if 'police' in item_lower and 'call police' not in item_lower:
                return False
        
        return True
    
    def _get_priority_level(self, item: str, query_words: set) -> int:
        """Get priority level for context item"""
        item_lower = item.lower()
        
        # Highest priority for crisis/emergency content
        if any(word in item_lower for word in ['emergency', 'immediately', 'crisis', '911', '988']):
            return 10
        
        # High priority for actionable guidance
        if any(word in item_lower for word in ['contact', 'report', 'block', 'tell', 'document']):
            return 8
        
        # Medium priority for preventive measures
        if any(word in item_lower for word in ['prevent', 'avoid', 'protect', 'secure']):
            return 6
        
        # Lower priority for general information
        return 4
    
    def _is_action_oriented(self, item: str) -> bool:
        """Check if item contains actionable guidance"""
        action_indicators = [
            'contact', 'call', 'report', 'block', 'tell', 'document', 'save',
            'screenshot', 'record', 'inform', 'seek', 'ask', 'use', 'create',
            'establish', 'implement', 'coordinate', 'connect', 'maintain'
        ]
        
        item_lower = item.lower()
        return any(indicator in item_lower for indicator in action_indicators)
    
    def _get_age_appropriateness_factor(self, item: str, user_age: int) -> float:
        """Calculate age appropriateness factor"""
        if user_age >= 16:
            return 1.0  # All content appropriate
        elif user_age >= 13:
            # Slightly reduce complex legal/advanced content
            if any(word in item.lower() for word in ['legal', 'law enforcement', 'criminal']):
                return 0.8
            return 1.0
        else:
            # More filtering for younger users
            if any(word in item.lower() for word in ['legal', 'police', 'court', 'criminal']):
                return 0.6
            return 1.0
    
    def _calculate_length_factor(self, item: str) -> float:
        """Calculate length appropriateness factor"""
        length = len(item)
        
        if 50 <= length <= 200:
            return 1.0  # Optimal length
        elif length < 30:
            return 0.7  # Too short, might lack detail
        elif length > 300:
            return 0.8  # Might be too verbose
        else:
            return 0.9  # Acceptable length
    
    def _calculate_semantic_similarity(self, query_words: set, item_words: set) -> float:
        """Calculate semantic similarity beyond exact word matches"""
        semantic_score = 0
        
        # Check for semantic relationships
        for query_word in query_words:
            for category, related_words in self.semantic_mappings.items():
                if query_word in related_words:
                    # Find related words in item
                    related_in_item = item_words & set(related_words)
                    if related_in_item:
                        semantic_score += len(related_in_item) * 0.1
        
        return min(semantic_score, 0.5)  # Cap semantic contribution
    
    def _generate_context_recommendations(self, contexts: List[Dict[str, Any]], context_type: str) -> List[str]:
        """Generate actionable recommendations based on retrieved contexts"""
        recommendations = []
        
        if not contexts:
            return ["No specific guidance available - consult with trusted adults"]
        
        # Extract action items from high-relevance contexts
        high_relevance_contexts = [ctx for ctx in contexts if ctx['relevance_score'] > 0.6]
        
        if context_type == 'crisis_intervention':
            recommendations.extend([
                "🚨 IMMEDIATE ACTION: Contact crisis resources (988) or emergency services (911)",
                "📞 SAFETY: Inform trusted adults and ensure continuous supervision",
                "🏥 PROFESSIONAL: Seek immediate mental health professional assistance"
            ])
        elif context_type == 'cyberbullying_intervention':
            recommendations.extend([
                "📸 EVIDENCE: Document all incidents with screenshots and records",
                "🚫 PROTECTION: Block perpetrators and report to platform administrators",
                "👥 SUPPORT: Inform trusted adults and build support network"
            ])
        elif context_type == 'online_safety_protocols':
            recommendations.extend([
                "🔒 PRIVACY: Never share personal information with strangers online",
                "👨‍👩‍👧‍👦 TRANSPARENCY: Keep trusted adults informed of online activities",
                "⚠️ AWARENESS: Report suspicious behavior immediately"
            ])
        
        # Add specific recommendations from high-relevance contexts
        for ctx in high_relevance_contexts[:2]:
            if ctx['action_oriented']:
                recommendations.append(f"💡 {ctx['content'][:80]}...")
        
        return recommendations[:6]  # Limit to top 6 recommendations
    
    def search_knowledge_base(self, search_query: str, category: Optional[str] = None) -> Dict[str, Any]:
        """Search the knowledge base with advanced filtering"""
        search_words = set(search_query.lower().split())
        results = []
        
        # Determine which categories to search
        categories_to_search = [category] if category else list(self.knowledge_base.keys())
        
        for cat in categories_to_search:
            if cat in self.knowledge_base:
                for item in self.knowledge_base[cat]:
                    item_words = set(item.lower().split())
                    relevance = len(search_words & item_words) / len(search_words | item_words)
                    
                    if relevance > 0.1:
                        results.append({
                            'content': item,
                            'category': cat,
                            'relevance': relevance,
                            'word_matches': list(search_words & item_words)
                        })
        
        # Sort by relevance
        results.sort(key=lambda x: x['relevance'], reverse=True)
        
        return {
            'results': results,
            'total_found': len(results),
            'search_query': search_query,
            'categories_searched': categories_to_search
        }
    
    def add_knowledge_entry(self, category: str, content: str, source: str = "user_added") -> bool:
        """Add new knowledge entry to the system"""
        try:
            if category not in self.knowledge_base:
                self.knowledge_base[category] = []
            
            # Check for duplicates
            if content not in self.knowledge_base[category]:
                self.knowledge_base[category].append(content)
                logger.info(f"📝 Added knowledge entry to {category}: {content[:50]}...")
                return True
            else:
                logger.info(f"📝 Duplicate knowledge entry ignored: {content[:50]}...")
                return False
                
        except Exception as e:
            logger.error(f"Error adding knowledge entry: {e}")
            return False
    
    def get_system_status(self) -> Dict[str, Any]:
        """Get comprehensive RAG system status"""
        return {
            'system_status': 'ACTIVE',
            'knowledge_base_stats': {
                'total_categories': len(self.knowledge_base),
                'total_entries': sum(len(items) for items in self.knowledge_base.values()),
                'categories': {cat: len(items) for cat, items in self.knowledge_base.items()}
            },
            'cache_stats': {
                'cache_size': len(self.context_cache),
                'cache_hit_rate': (self.retrieval_stats['cache_hits'] / max(self.retrieval_stats['queries'], 1)) * 100
            },
            'retrieval_stats': self.retrieval_stats.copy(),
            'performance_metrics': {
                'avg_contexts_per_query': (
                    self.retrieval_stats['total_contexts_retrieved'] / 
                    max(self.retrieval_stats['hits'], 1)
                ),
                'categories_coverage': len(self.retrieval_stats['categories_accessed'])
            }
        }
    
    def export_knowledge_base(self) -> Dict[str, Any]:
        """Export knowledge base for backup or analysis"""
        return {
            'export_timestamp': datetime.now().isoformat(),
            'knowledge_base': self.knowledge_base.copy(),
            'system_metadata': {
                'total_entries': sum(len(items) for items in self.knowledge_base.values()),
                'categories': list(self.knowledge_base.keys()),
                'semantic_mappings': self.semantic_mappings,
                'context_weights': self.context_weights
            }
        }
    
    def clear_cache(self):
        """Clear the context cache"""
        cache_size = len(self.context_cache)
        self.context_cache.clear()
        logger.info(f"🧹 Cleared RAG cache: {cache_size} entries removed")