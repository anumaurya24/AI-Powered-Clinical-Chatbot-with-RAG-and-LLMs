"""
AI Manager - Advanced Prompt Engineering for Child Safety
"""
import openai
import json
import time
from typing import Dict, List, Any, Optional

class UltimateAIManager:
    def __init__(self, api_key: str):
        self.api_key = api_key
        if api_key and api_key.startswith('sk-'):
            openai.api_key = api_key
            self.openai_available = True
        else:
            self.openai_available = False
            
        print(f"🤖 AI Manager initialized - OpenAI: {'✅' if self.openai_available else '❌'}")
    
    def zero_shot_analysis(self, message: str, user_age: int) -> Dict[str, Any]:
        """Zero-shot learning for immediate threat detection"""
        if not self.openai_available:
            return self._fallback_zero_shot(message, user_age)
        
        try:
            prompt = f"""You are an expert child safety AI assistant. Analyze this message from a {user_age}-year-old for safety concerns.

Message: "{message}"

Provide immediate assessment focusing on:
1. Crisis indicators (suicide, self-harm, depression)
2. Cyberbullying signs
3. Predator interaction warnings
4. Immediate safety needs

Respond with helpful, age-appropriate guidance and resources."""

            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                max_tokens=500,
                temperature=0.3
            )
            
            return {
                'success': True,
                'response': response.choices[0].message.content,
                'technique': 'zero_shot',
                'model_used': 'gpt-3.5-turbo',
                'tokens_used': response.usage.total_tokens,
                'confidence': 0.85
            }
            
        except Exception as e:
            print(f"OpenAI Zero-shot error: {e}")
            return self._fallback_zero_shot(message, user_age)
    
    def few_shot_analysis(self, message: str, user_age: int, category: str) -> Dict[str, Any]:
        """Few-shot learning with examples"""
        if not self.openai_available:
            return self._fallback_few_shot(message, user_age, category)
        
        examples = self._get_few_shot_examples(category)
        
        try:
            prompt = f"""You are a child safety expert. Here are examples of {category} situations and appropriate responses:

{examples}

Now analyze this message from a {user_age}-year-old:
Message: "{message}"

Provide a helpful response following the pattern of the examples above."""

            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                max_tokens=600,
                temperature=0.4
            )
            
            return {
                'success': True,
                'response': response.choices[0].message.content,
                'technique': 'few_shot',
                'model_used': 'gpt-3.5-turbo',
                'tokens_used': response.usage.total_tokens,
                'confidence': 0.88
            }
            
        except Exception as e:
            print(f"OpenAI Few-shot error: {e}")
            return self._fallback_few_shot(message, user_age, category)
    
    def chain_of_thought_analysis(self, message: str, user_age: int) -> Dict[str, Any]:
        """Chain-of-thought reasoning"""
        if not self.openai_available:
            return self._fallback_chain_of_thought(message, user_age)
        
        try:
            prompt = f"""You are a child safety expert. Analyze this message step-by-step:

Message from {user_age}-year-old: "{message}"

Think through this step by step:
1. What type of situation is this?
2. What are the immediate safety concerns?
3. What resources or actions are needed?
4. What is the appropriate response tone and content?
5. What follow-up might be needed?

Provide your reasoning and then give a helpful response."""

            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                max_tokens=700,
                temperature=0.5
            )
            
            return {
                'success': True,
                'response': response.choices[0].message.content,
                'technique': 'chain_of_thought',
                'model_used': 'gpt-3.5-turbo',
                'tokens_used': response.usage.total_tokens,
                'confidence': 0.90
            }
            
        except Exception as e:
            print(f"OpenAI Chain-of-thought error: {e}")
            return self._fallback_chain_of_thought(message, user_age)
    
    def comprehensive_analysis(self, message: str, user_age: int, rag_context: Dict, dataset_analysis: Dict) -> Dict[str, Any]:
        """Comprehensive analysis using all techniques"""
        if not self.openai_available:
            return self._fallback_comprehensive(message, user_age, rag_context, dataset_analysis)
        
        try:
            context_str = self._format_context(rag_context, dataset_analysis)
            
            prompt = f"""You are an advanced child safety AI using multiple analysis techniques.

Message from {user_age}-year-old: "{message}"

Additional Context:
{context_str}

Use comprehensive analysis:
1. Zero-shot: Immediate threat assessment
2. Few-shot: Pattern matching from examples
3. Chain-of-thought: Step-by-step reasoning
4. Context integration: Use provided background

Provide the most accurate and helpful response possible."""

            response = openai.ChatCompletion.create(
                model="gpt-4" if "gpt-4" in str(self.api_key) else "gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                max_tokens=800,
                temperature=0.3
            )
            
            return {
                'success': True,
                'response': response.choices[0].message.content,
                'technique': 'comprehensive',
                'model_used': 'gpt-4' if "gpt-4" in str(self.api_key) else "gpt-3.5-turbo",
                'tokens_used': response.usage.total_tokens,
                'confidence': 0.95
            }
            
        except Exception as e:
            print(f"OpenAI Comprehensive error: {e}")
            return self._fallback_comprehensive(message, user_age, rag_context, dataset_analysis)
    
    def _get_few_shot_examples(self, category: str) -> str:
        """Get training examples for few-shot learning"""
        examples = {
            'cyberbullying': """
Example 1:
Input: "Kids at school are posting mean things about me online"
Response: "I'm sorry you're experiencing cyberbullying. Here's what you can do:
1. Document everything with screenshots
2. Block the people posting mean content
3. Report to the platform and school
4. Talk to trusted adults
Resources: StopBullying.gov"

Example 2:
Input: "Someone created a fake account pretending to be me"
Response: "This is identity impersonation, which is serious. Take action:
1. Screenshot the fake profile
2. Report for impersonation to the platform
3. Alert your contacts it's fake
4. Tell parents/guardians immediately"
""",
            'crisis_support': """
Example 1:
Input: "I feel hopeless and don't want to be here anymore"
Response: "I'm very concerned about you. These feelings are serious but help is available:
• Call 988 (Suicide & Crisis Lifeline) - 24/7
• Text HOME to 741741 (Crisis Text Line)
• Tell a trusted adult immediately
You matter and these feelings can change with support."

Example 2:
Input: "Everything feels overwhelming and I can't handle it"
Response: "These overwhelming feelings are valid but you don't have to face them alone:
• Crisis support: 988 or text 741741
• Talk to counselor, parent, or trusted adult
• Focus on immediate safety and getting help
Professional support can make a real difference."
"""
        }
        return examples.get(category, examples['cyberbullying'])
    
    def _format_context(self, rag_context: Dict, dataset_analysis: Dict) -> str:
        """Format context for comprehensive analysis"""
        context_parts = []
        
        if rag_context.get('contexts'):
            context_parts.append("Knowledge Base Context:")
            for ctx in rag_context['contexts'][:2]:
                context_parts.append(f"- {ctx}")
        
        if dataset_analysis.get('is_cyberbullying'):
            context_parts.append(f"Cyberbullying Analysis: {dataset_analysis['confidence']:.1%} confidence")
        
        return "\n".join(context_parts) if context_parts else "No additional context available."
    
    # Fallback methods for when OpenAI isn't available
    def _fallback_zero_shot(self, message: str, user_age: int) -> Dict[str, Any]:
        """Fallback zero-shot analysis"""
        message_lower = message.lower()
        
        if any(word in message_lower for word in ['suicide', 'kill myself', 'want to die', 'hurt myself']):
            response = """🚨 I'm very concerned about what you've shared. These feelings are serious but help is available right now:

**IMMEDIATE HELP:**
• Call 988 (Suicide & Crisis Lifeline) - 24/7
• Text HOME to 741741 (Crisis Text Line)
• Tell a trusted adult immediately

You matter and these feelings can change with proper support."""
        
        elif any(word in message_lower for word in ['bullying', 'harassment', 'mean things', 'fake account']):
            response = """I'm sorry you're dealing with this situation. Here's how to handle cyberbullying:

**IMMEDIATE ACTIONS:**
• Document everything with screenshots
• Block the person harassing you
• Report to the platform
• Tell trusted adults

**RESOURCES:**
• StopBullying.gov: https://www.stopbullying.gov/
• Report tools on all major platforms"""
        
        else:
            response = f"""I'm here to help with safety concerns. Based on your message, I can provide guidance on:

• Online safety and digital citizenship
• Cyberbullying prevention and response
• Crisis support and resources
• Connecting with appropriate help

What specific safety topic would you like to discuss?"""
        
        return {
            'success': True,
            'response': response,
            'technique': 'zero_shot_fallback',
            'model_used': 'fallback_system',
            'tokens_used': 0,
            'confidence': 0.80
        }
    
    def _fallback_few_shot(self, message: str, user_age: int, category: str) -> Dict[str, Any]:
        """Fallback few-shot analysis"""
        return {
            'success': True,
            'response': f"Based on similar {category} situations, I recommend documenting the issue, involving trusted adults, and using appropriate reporting tools. Would you like specific guidance for your situation?",
            'technique': 'few_shot_fallback',
            'model_used': 'fallback_system',
            'tokens_used': 0,
            'confidence': 0.75
        }
    
    def _fallback_chain_of_thought(self, message: str, user_age: int) -> Dict[str, Any]:
        """Fallback chain-of-thought analysis"""
        return {
            'success': True,
            'response': "Let me think through your situation step by step and provide appropriate guidance based on child safety best practices. What specific aspect would you like help with?",
            'technique': 'chain_of_thought_fallback',
            'model_used': 'fallback_system',
            'tokens_used': 0,
            'confidence': 0.70
        }
    
    def _fallback_comprehensive(self, message: str, user_age: int, rag_context: Dict, dataset_analysis: Dict) -> Dict[str, Any]:
        """Fallback comprehensive analysis"""
        return {
            'success': True,
            'response': "Using comprehensive analysis of your situation, I can help you with safety planning, resource connections, and appropriate next steps. What would be most helpful right now?",
            'technique': 'comprehensive_fallback',
            'model_used': 'fallback_system',
            'tokens_used': 0,
            'confidence': 0.85
        }