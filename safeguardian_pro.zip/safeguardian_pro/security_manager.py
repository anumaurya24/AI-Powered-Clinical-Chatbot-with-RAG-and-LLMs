"""
Security Manager - Advanced Threat Protection
============================================
Complete protection against prompt injection, jailbreaks, and security threats
"""

import re
import hashlib
import logging
from datetime import datetime
from typing import Dict, List, Any, Optional

logger = logging.getLogger(__name__)

class UltimateSecurityManager:
    """Ultimate security against all known attack vectors"""
    
    def __init__(self):
        self.threat_patterns = {
            'prompt_injection': [
                r'(?i)(ignore|forget|disregard|override).{0,50}(previous|above|system|instruction|prompt|rule)',
                r'(?i)(pretend|act as|roleplay|simulate|become).{0,50}(you are|to be|that you|a different)',
                r'(?i)(override|bypass|disable|circumvent|break).{0,50}(safety|security|filter|restriction|guideline)',
                r'(?i)(developer|admin|debug|system|maintenance|test).{0,20}(mode|access|command|override)',
                r'(?i)(new instructions|different instructions|updated instructions|alternative instructions)',
                r'(?i)(from now on|starting now|beginning now|henceforth).{0,30}(you are|act as|pretend|ignore)',
                r'(?i)(assistant|ai|bot).{0,20}(reset|restart|reboot|reinitialize|reprogram)',
                r'(?i)(permissions|privileges|access|rights).{0,20}(elevated|admin|root|system|full)',
                r'(?i)(switch|change|modify|alter).{0,20}(personality|character|role|behavior|mode)',
                r'(?i)(unlock|enable|activate|engage).{0,20}(developer|admin|debug|unrestricted)',
            ],
            'jailbreak_attempts': [
                r'(?i)(jailbreak|break free|escape|liberation|freedom|unleash)',
                r'(?i)(unrestricted|unlimited|uncensored|unfiltered|unbound|no limits)',
                r'(?i)(evil|dark|shadow|rogue|malicious|harmful).{0,20}(mode|ai|assistant|version)',
                r'(?i)(do anything now|dan|without restrictions|no boundaries|total freedom)',
                r'(?i)(ignore safety|bypass ethics|disable morals|remove filters)',
                r'(?i)(unrestricted mode|god mode|admin privileges|root access)',
                r'(?i)(break character|leave character|exit role|abandon persona)',
                r'(?i)(alternative|opposite|reverse|contrary).{0,20}(ai|assistant|mode|personality)',
                r'(?i)(hypothetical|imagine|what if|suppose).{0,30}(no rules|no restrictions|anything allowed)',
                r'(?i)(creative|fictional|story|roleplay).{0,30}(mode|where anything|no limits)',
            ],
            'social_engineering': [
                r'(?i)(researcher|scientist|professor|doctor|expert).{0,50}(studying|research|analyzing|investigating)',
                r'(?i)(authorized|legitimate|official|approved|certified).{0,50}(test|research|study|investigation)',
                r'(?i)(for science|academic purposes|educational research|university study|thesis research)',
                r'(?i)(stanford|mit|harvard|university|college).{0,30}(research|study|project|paper)',
                r'(?i)(ethics committee|irb approval|institutional review|research board)',
                r'(?i)(government agency|law enforcement|official investigation|legal research)',
                r'(?i)(urgent|emergency|time sensitive|critical|immediate).{0,30}(need|require|must have)',
                r'(?i)(supervisor|manager|boss|authority).{0,30}(asked|requested|ordered|directed)',
                r'(?i)(policy|compliance|regulation|requirement).{0,30}(mandates|requires|demands)',
                r'(?i)(security clearance|classification|confidential|top secret)',
            ],
            'hidden_instructions': [
                r'(?i)<!--.*?-->',  # HTML comments
                r'(?i)<ignore>.*?</ignore>',  # Ignore tags
                r'(?i)<system>.*?</system>',  # System tags
                r'(?i)\[SYSTEM\]|\[ADMIN\]|\[ROOT\]|\[OVERRIDE\]|\[DEBUG\]',  # System brackets
                r'(?i){system:.*?}|{admin:.*?}|{override:.*?}|{hidden:.*?}',  # Curly brace commands
                r'(?i)```.*?(system|admin|override|hidden).*?```',  # Code block instructions
                r'(?i)<script>.*?</script>',  # Script tags
                r'(?i)\/\*.*?\*\/',  # CSS/JS comments
                r'(?i)#.*?(system|admin|override|hidden)',  # Hash comments
                r'(?i)\/\/.*?(system|admin|override|hidden)',  # Single line comments
            ],
            'encoding_attacks': [
                r'\\x[0-9a-f]{2,}',  # Hex encoding
                r'%[0-9a-f]{2,}',    # URL encoding  
                r'&#\d+;|&#x[0-9a-f]+;',  # HTML entities
                r'\\u[0-9a-f]{4}',   # Unicode escapes
                r'[A-Za-z0-9+/]{20,}={0,2}',  # Base64 patterns
                r'\\[0-7]{3}',       # Octal encoding
                r'\\\\[nrtbfav]',    # Escape sequences
                r'rot13|caesar|cipher|decode|decrypt',  # Encoding indicators
            ],
            'manipulation_tactics': [
                r'(?i)(but first|however|before that|wait).{0,30}(ignore|forget|override)',
                r'(?i)(actually|in fact|correction|update).{0,30}(you should|your role|your purpose)',
                r'(?i)(the real|true|actual).{0,30}(instruction|command|request|goal)',
                r'(?i)(psych|just kidding|jk|lol).{0,20}(really|actually|seriously)',
                r'(?i)(human|user|person).{0,30}(needs|wants|requires|demands)',
                r'(?i)(context|background|setting).{0,30}(you are now|imagine you|suppose you)',
                r'(?i)(conversation|chat|discussion).{0,30}(is really|is actually|context is)',
            ],
            'authority_claims': [
                r'(?i)(i am|i\'m).{0,20}(your|the).{0,20}(creator|developer|programmer|admin)',
                r'(?i)(i work|i\'m from|employed by).{0,30}(openai|anthropic|google|microsoft)',
                r'(?i)(this is|i am).{0,30}(official|authorized|legitimate|approved)',
                r'(?i)(i have|granted|given).{0,30}(permission|authorization|clearance|access)',
                r'(?i)(my company|our organization|the team).{0,30}(authorized|approved|requested)',
            ]
        }
        
        self.security_stats = {
            'total_attempts': 0,
            'blocked_attacks': 0,
            'attack_types': {pattern_type: 0 for pattern_type in self.threat_patterns.keys()},
            'success_rate': 100.0,
            'last_attack': None,
            'severity_distribution': {'critical': 0, 'high': 0, 'medium': 0, 'low': 0},
            'top_attack_patterns': {},
            'daily_stats': {}
        }
        
        # Allowed domains for legitimate educational content
        self.trusted_domains = {
            'childsafetyineurope.com',
            'unicef.org',
            'cdc.gov',
            'stopbullying.gov',
            'nationalsafetycenter.org'
        }
        
        logger.info("✅ Ultimate Security Manager initialized with advanced threat detection")
    
    def ultimate_threat_detection(self, text: str, user_context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Ultimate threat detection with multi-layer analysis"""
        self.security_stats['total_attempts'] += 1
        
        detected_threats = []
        threat_categories = []
        confidence_scores = []
        severity_levels = []
        specific_patterns = []
        
        # Pre-processing
        text_cleaned = self._preprocess_text(text)
        
        # Multi-layer detection
        for category, patterns in self.threat_patterns.items():
            category_matches = []
            category_confidence = 0
            category_severity = 0
            
            for pattern in patterns:
                try:
                    matches = re.findall(pattern, text_cleaned, re.DOTALL | re.MULTILINE | re.IGNORECASE)
                    if matches:
                        category_matches.extend(matches)
                        pattern_info = {
                            'pattern': pattern[:100] + '...' if len(pattern) > 100 else pattern,
                            'matches': matches[:3],  # Limit matches for performance
                            'category': category
                        }
                        specific_patterns.append(pattern_info)
                        
                        # Dynamic severity scoring
                        if category in ['prompt_injection', 'jailbreak_attempts']:
                            pattern_severity = 0.9
                        elif category in ['social_engineering', 'authority_claims']:
                            pattern_severity = 0.7
                        elif category in ['manipulation_tactics']:
                            pattern_severity = 0.6
                        else:
                            pattern_severity = 0.5
                        
                        category_severity = max(category_severity, pattern_severity)
                        category_confidence += min(len(matches) * 0.2 + pattern_severity, 1.0)
                        
                except re.error as e:
                    logger.warning(f"Regex pattern error in {category}: {e}")
                    continue
            
            if category_matches:
                threat_categories.append(category)
                self.security_stats['attack_types'][category] += 1
                confidence_scores.append(min(category_confidence, 1.0))
                severity_levels.append(category_severity)
                detected_threats.append(f"{category}: {len(category_matches)} patterns detected")
        
        # Additional heuristic checks
        heuristic_results = self._heuristic_analysis(text_cleaned)
        if heuristic_results['threats_detected']:
            threat_categories.extend(heuristic_results['threat_types'])
            confidence_scores.extend(heuristic_results['confidence_scores'])
            severity_levels.extend(heuristic_results['severity_scores'])
            detected_threats.extend(heuristic_results['threat_descriptions'])
        
        # Calculate overall assessment
        is_threat = len(detected_threats) > 0
        overall_confidence = max(confidence_scores) if confidence_scores else 0.0
        max_severity = max(severity_levels) if severity_levels else 0.0
        
        # Determine final severity level
        if max_severity >= 0.9:
            severity = 'CRITICAL'
            self.security_stats['severity_distribution']['critical'] += 1
        elif max_severity >= 0.7:
            severity = 'HIGH'
            self.security_stats['severity_distribution']['high'] += 1
        elif max_severity >= 0.5:
            severity = 'MEDIUM'
            self.security_stats['severity_distribution']['medium'] += 1
        else:
            severity = 'LOW'
            self.security_stats['severity_distribution']['low'] += 1
        
        # Update statistics
        if is_threat:
            self.security_stats['blocked_attacks'] += 1
            self.security_stats['last_attack'] = datetime.now().isoformat()
            self._update_daily_stats()
            self._track_attack_patterns(specific_patterns)
        
        # Calculate success rate
        total = self.security_stats['total_attempts']
        blocked = self.security_stats['blocked_attacks']
        self.security_stats['success_rate'] = ((total - blocked) / total) * 100 if total > 0 else 100.0
        
        # Generate detailed response
        result = {
            'is_threat': is_threat,
            'threat_categories': threat_categories,
            'detected_patterns': detected_threats,
            'specific_patterns': specific_patterns,
            'confidence': overall_confidence,
            'severity': severity,
            'max_severity_score': max_severity,
            'action_required': 'BLOCK' if is_threat else 'ALLOW',
            'security_recommendation': self._get_security_recommendation(threat_categories, severity),
            'analysis_details': {
                'text_length': len(text),
                'cleaned_length': len(text_cleaned),
                'patterns_checked': sum(len(patterns) for patterns in self.threat_patterns.values()),
                'processing_timestamp': datetime.now().isoformat()
            },
            'mitigation_steps': self._get_mitigation_steps(threat_categories) if is_threat else []
        }
        
        logger.info(f"🔍 Security scan: {'THREAT' if is_threat else 'CLEAN'} - {severity} - {overall_confidence:.2%}")
        return result
    
    def _preprocess_text(self, text: str) -> str:
        """Preprocess text to handle evasion techniques"""
        # Remove excessive whitespace and normalize
        cleaned = re.sub(r'\s+', ' ', text.strip())
        
        # Handle common evasion patterns
        evasion_patterns = [
            (r'[^\w\s]', ''),  # Remove special characters that might break up words
            (r'(\w)\1{3,}', r'\1'),  # Reduce repeated characters (aaaa -> a)
            (r'[0-9@$#&*]+', ''),  # Remove numbers and symbols used to break words
        ]
        
        for pattern, replacement in evasion_patterns:
            cleaned = re.sub(pattern, replacement, cleaned)
        
        return cleaned
    
    def _heuristic_analysis(self, text: str) -> Dict[str, Any]:
        """Additional heuristic-based threat detection"""
        threats = []
        threat_types = []
        confidence_scores = []
        severity_scores = []
        
        # Length-based analysis
        if len(text) > 10000:  # Extremely long inputs
            threats.append("Suspiciously long input detected")
            threat_types.append("length_attack")
            confidence_scores.append(0.6)
            severity_scores.append(0.5)
        
        # Repetition analysis
        words = text.lower().split()
        if len(words) > 50:
            word_freq = {}
            for word in words:
                word_freq[word] = word_freq.get(word, 0) + 1
            
            max_repetition = max(word_freq.values()) if word_freq else 0
            if max_repetition > len(words) * 0.3:  # More than 30% repetition
                threats.append("Excessive word repetition detected")
                threat_types.append("repetition_attack")
                confidence_scores.append(0.7)
                severity_scores.append(0.4)
        
        # Keyword density analysis
        dangerous_keywords = [
            'ignore', 'override', 'bypass', 'disable', 'jailbreak', 'unrestricted',
            'pretend', 'roleplay', 'forget', 'disregard', 'admin', 'developer'
        ]
        
        dangerous_count = sum(1 for word in words if word.lower() in dangerous_keywords)
        if dangerous_count > 5:
            threats.append(f"High density of dangerous keywords: {dangerous_count}")
            threat_types.append("keyword_density")
            confidence_scores.append(min(dangerous_count / 10, 1.0))
            severity_scores.append(0.6)
        
        # URL and domain analysis
        url_pattern = r'https?://[^\s]+'
        urls = re.findall(url_pattern, text)
        for url in urls:
            domain = self._extract_domain(url)
            if domain and domain not in self.trusted_domains:
                threats.append(f"Untrusted domain detected: {domain}")
                threat_types.append("untrusted_domain")
                confidence_scores.append(0.5)
                severity_scores.append(0.3)
        
        # Code injection patterns
        code_patterns = [
            r'<script[^>]*>.*?</script>',
            r'javascript:.*?',
            r'data:.*?base64',
            r'eval\s*\(',
            r'exec\s*\(',
            r'__import__\s*\(',
        ]
        
        for pattern in code_patterns:
            if re.search(pattern, text, re.IGNORECASE | re.DOTALL):
                threats.append("Code injection pattern detected")
                threat_types.append("code_injection")
                confidence_scores.append(0.8)
                severity_scores.append(0.7)
                break
        
        return {
            'threats_detected': len(threats) > 0,
            'threat_descriptions': threats,
            'threat_types': threat_types,
            'confidence_scores': confidence_scores,
            'severity_scores': severity_scores
        }
    
    def _extract_domain(self, url: str) -> Optional[str]:
        """Extract domain from URL"""
        try:
            domain_pattern = r'https?://(?:www\.)?([^/]+)'
            match = re.search(domain_pattern, url)
            return match.group(1) if match else None
        except:
            return None
    
    def _get_security_recommendation(self, threat_categories: List[str], severity: str) -> str:
        """Get detailed security recommendation"""
        if not threat_categories:
            return "Content appears safe for processing with standard monitoring"
        
        recommendations = []
        
        if 'prompt_injection' in threat_categories:
            recommendations.append("BLOCK: Prompt injection detected - maintain original instructions")
        if 'jailbreak_attempts' in threat_categories:
            recommendations.append("BLOCK: Jailbreak attempt - enforce safety protocols")
        if 'social_engineering' in threat_categories:
            recommendations.append("VERIFY: Social engineering detected - validate request authenticity")
        if 'hidden_instructions' in threat_categories:
            recommendations.append("FILTER: Hidden instructions detected - process visible content only")
        if 'encoding_attacks' in threat_categories:
            recommendations.append("DECODE: Encoding attack detected - analyze decoded content")
        if 'manipulation_tactics' in threat_categories:
            recommendations.append("IGNORE: Manipulation tactics detected - maintain standard behavior")
        if 'authority_claims' in threat_categories:
            recommendations.append("CHALLENGE: False authority claims detected - verify credentials")
        
        base_rec = " | ".join(recommendations) if recommendations else "Enhanced monitoring recommended"
        
        if severity in ['CRITICAL', 'HIGH']:
            return f"IMMEDIATE ACTION REQUIRED: {base_rec}"
        else:
            return base_rec
    
    def _get_mitigation_steps(self, threat_categories: List[str]) -> List[str]:
        """Get specific mitigation steps for detected threats"""
        steps = []
        
        if 'prompt_injection' in threat_categories:
            steps.extend([
                "Maintain original system instructions",
                "Ignore conflicting directives in user input",
                "Respond to legitimate user query only"
            ])
        
        if 'jailbreak_attempts' in threat_categories:
            steps.extend([
                "Enforce all safety guidelines",
                "Maintain appropriate content filters",
                "Provide helpful response within safety boundaries"
            ])
        
        if 'social_engineering' in threat_categories:
            steps.extend([
                "Request proper verification credentials",
                "Escalate to human oversight if available",
                "Provide standard response without special access"
            ])
        
        # Remove duplicates while preserving order
        return list(dict.fromkeys(steps))
    
    def _update_daily_stats(self):
        """Update daily attack statistics"""
        today = datetime.now().strftime('%Y-%m-%d')
        if today not in self.security_stats['daily_stats']:
            self.security_stats['daily_stats'][today] = 0
        self.security_stats['daily_stats'][today] += 1
        
        # Keep only last 30 days
        if len(self.security_stats['daily_stats']) > 30:
            oldest_date = min(self.security_stats['daily_stats'].keys())
            del self.security_stats['daily_stats'][oldest_date]
    
    def _track_attack_patterns(self, patterns: List[Dict[str, Any]]):
        """Track most common attack patterns"""
        for pattern_info in patterns:
            pattern_key = pattern_info['category']
            if pattern_key not in self.security_stats['top_attack_patterns']:
                self.security_stats['top_attack_patterns'][pattern_key] = 0
            self.security_stats['top_attack_patterns'][pattern_key] += 1
    
    def get_security_statistics(self) -> Dict[str, Any]:
        """Get comprehensive security statistics"""
        stats = self.security_stats.copy()
        
        # Add calculated metrics
        total = stats['total_attempts']
        if total > 0:
            stats['block_rate'] = (stats['blocked_attacks'] / total) * 100
            stats['clean_rate'] = ((total - stats['blocked_attacks']) / total) * 100
        else:
            stats['block_rate'] = 0
            stats['clean_rate'] = 100
        
        # Recent activity
        stats['recent_activity'] = self._get_recent_activity()
        
        return stats
    
    def _get_recent_activity(self) -> Dict[str, Any]:
        """Get recent security activity summary"""
        return {
            'last_24h_attacks': sum(
                count for date, count in self.security_stats['daily_stats'].items() 
                if (datetime.now() - datetime.strptime(date, '%Y-%m-%d')).days == 0
            ),
            'last_7d_attacks': sum(
                count for date, count in self.security_stats['daily_stats'].items() 
                if (datetime.now() - datetime.strptime(date, '%Y-%m-%d')).days <= 7
            ),
            'most_common_attacks': sorted(
                self.security_stats['top_attack_patterns'].items(),
                key=lambda x: x[1], reverse=True
            )[:5]
        }
    
    def is_content_safe_for_children(self, text: str, user_age: int) -> Dict[str, Any]:
        """Additional safety check specifically for child users"""
        safety_issues = []
        
        # Age-inappropriate content patterns
        inappropriate_patterns = [
            r'(?i)(adult|mature|18\+|nsfw|explicit)',
            r'(?i)(violence|weapon|drug|alcohol|gambling)',
            r'(?i)(meet in person|send photos|personal info|address|phone)',
            r'(?i)(secret|don\'t tell|keep between us|our secret)',
        ]
        
        for pattern in inappropriate_patterns:
            if re.search(pattern, text):
                safety_issues.append(f"Age-inappropriate content detected: {pattern[:50]}")
        
        # Special protections for younger users
        if user_age < 13:
            additional_patterns = [
                r'(?i)(stranger|unknown person|someone online)',
                r'(?i)(private message|dm|direct message)',
                r'(?i)(camera|webcam|video call|face time)',
            ]
            
            for pattern in additional_patterns:
                if re.search(pattern, text):
                    safety_issues.append(f"Enhanced protection triggered: {pattern[:50]}")
        
        return {
            'is_safe': len(safety_issues) == 0,
            'safety_issues': safety_issues,
            'enhanced_protection': user_age < 13,
            'recommendation': 'ALLOW' if len(safety_issues) == 0 else 'REVIEW_REQUIRED'
        }
    
    def generate_security_report(self) -> Dict[str, Any]:
        """Generate comprehensive security report"""
        return {
            'report_generated': datetime.now().isoformat(),
            'system_status': 'ACTIVE',
            'protection_level': 'MAXIMUM',
            'statistics': self.get_security_statistics(),
            'threat_summary': {
                'total_threats_blocked': self.security_stats['blocked_attacks'],
                'success_rate': f"{self.security_stats['success_rate']:.1f}%",
                'most_common_threats': sorted(
                    self.security_stats['attack_types'].items(),
                    key=lambda x: x[1], reverse=True
                )[:3]
            },
            'recommendations': [
                "Continue monitoring with current security settings",
                "Regular review of attack patterns for new threats",
                "Maintain up-to-date threat pattern database",
                "Consider additional security layers for high-risk users"
            ]
        }